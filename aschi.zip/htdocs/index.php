<?php
require_once __DIR__ . '/includes/functions.php';
$__title = 'Aschi — তাজা বাজার, দরজায় পৌঁছে যাবে';
require_once __DIR__ . '/includes/header.php';

$banners = $conn->query("SELECT * FROM banners WHERE status='active' ORDER BY sort_order, id");
$cats    = $conn->query("SELECT * FROM categories WHERE status='active' ORDER BY sort_order, id");
$featured = $conn->query("SELECT * FROM products WHERE status='active' AND is_featured=1 ORDER BY id DESC LIMIT 8");
$popular  = $conn->query("SELECT * FROM products WHERE status='active' ORDER BY sold_count DESC, id DESC LIMIT 8");

$catEmoji = ['কাঁচাবাজার' => '🧺', 'সবজি' => '🥬', 'মাছ' => '🐟', 'মাংস' => '🍗', 'ডেইলি নিডস' => '🛒'];
?>

<main class="container py-4">

  <?php if ($banners->num_rows): ?>
  <section id="promoSlider" class="carousel slide mb-5" data-bs-ride="carousel">
    <div class="carousel-inner rounded-4">
      <?php $i = 0; while ($b = $banners->fetch_assoc()): ?>
        <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
          <?php if ($b['link']): ?><a href="<?= h($b['link']) ?>"><?php endif; ?>
          <img src="<?= url('assets/images/banners/' . h($b['image'])) ?>" class="d-block w-100" alt="অফার">
          <?php if ($b['link']): ?></a><?php endif; ?>
        </div>
      <?php $i++; endwhile; ?>
    </div>
    <?php if ($banners->num_rows > 1): ?>
      <button class="carousel-control-prev" type="button" data-bs-target="#promoSlider" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span><span class="visually-hidden">আগের</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#promoSlider" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span><span class="visually-hidden">পরের</span>
      </button>
    <?php endif; ?>
  </section>
  <?php else: ?>
  <section class="bg-green-soft rounded-4 p-4 p-md-5 mb-5">
    <div class="row align-items-center g-3">
      <div class="col-md-8">
        <h1 class="fw-bold mb-2" style="font-size:30px">আজকের বাজার আজই পৌঁছে যাবে</h1>
        <p class="text-muted mb-3" style="max-width:52ch">
          সকালে কাটা মাছ, খেত থেকে তোলা সবজি, মাপা ওজনের মাংস — অর্ডার দিন, রাইডার নিয়ে আসছে।
        </p>
        <a href="<?= url('products.php') ?>" class="btn btn-green px-4">বাজার শুরু করুন</a>
      </div>
      <div class="col-md-4 text-center d-none d-md-block" style="font-size:86px">🛵</div>
    </div>
  </section>
  <?php endif; ?>

  <section class="mb-5">
    <div class="section-head">
      <h2 class="section-title">ক্যাটেগরি</h2>
      <a href="<?= url('products.php') ?>" class="fw-semibold">সব দেখুন</a>
    </div>
    <div class="row row-cols-3 row-cols-md-5 g-3">
      <?php while ($c = $cats->fetch_assoc()): ?>
      <div class="col">
        <a class="cat-card" href="<?= url('products.php?cat=' . (int)$c['id']) ?>">
          <?php if ($c['icon_image']): ?>
            <img class="icon-3d" src="<?= url('assets/images/categories/' . h($c['icon_image'])) ?>" alt="" loading="lazy">
          <?php else: ?>
            <span class="emoji"><?= $catEmoji[$c['name']] ?? '🧺' ?></span>
          <?php endif; ?>
          <span class="name"><?= h($c['name']) ?></span>
        </a>
      </div>
      <?php endwhile; ?>
    </div>
  </section>

  <?php if ($featured->num_rows): ?>
  <section class="mb-5">
    <div class="section-head">
      <h2 class="section-title">আজকের বাছাই</h2>
      <a href="<?= url('products.php') ?>" class="fw-semibold">সব দেখুন</a>
    </div>
    <div class="row row-cols-2 row-cols-md-4 g-3">
      <?php while ($p = $featured->fetch_assoc()): ?>
        <div class="col"><?php include __DIR__ . '/includes/product_card.php'; ?></div>
      <?php endwhile; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($popular->num_rows): ?>
  <section class="mb-5">
    <div class="section-head">
      <h2 class="section-title">জনপ্রিয় পণ্য</h2>
      <a href="<?= url('products.php?sort=popular') ?>" class="fw-semibold">সব দেখুন</a>
    </div>
    <div class="row row-cols-2 row-cols-md-4 g-3">
      <?php while ($p = $popular->fetch_assoc()): ?>
        <div class="col"><?php include __DIR__ . '/includes/product_card.php'; ?></div>
      <?php endwhile; ?>
    </div>
  </section>
  <?php endif; ?>

  <section class="row g-3 text-center">
    <div class="col-md-4">
      <div class="card-soft p-4 h-100">
        <div style="font-size:38px">🕗</div>
        <h3 class="h6 fw-bold mt-2">দিনে দুইবার ডেলিভারি</h3>
        <p class="text-muted small mb-0">সকাল ও সন্ধ্যার স্লট থেকে বেছে নিন।</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card-soft p-4 h-100">
        <div style="font-size:38px">📍</div>
        <h3 class="h6 fw-bold mt-2">রাইডার লাইভ ট্র্যাকিং</h3>
        <p class="text-muted small mb-0">অর্ডার কোথায় আছে, ম্যাপে দেখুন।</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card-soft p-4 h-100">
        <div style="font-size:38px">💵</div>
        <h3 class="h6 fw-bold mt-2">ক্যাশ অন ডেলিভারি</h3>
        <p class="text-muted small mb-0">পণ্য হাতে পেয়ে টাকা দিন।</p>
      </div>
    </div>
  </section>

</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
