<?php
/**
 * Shared bootstrap for the rider app API.
 * Auth: send the rider's api_token as `Authorization: Bearer <token>` or POST field `token`.
 */
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

function api_out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function api_fail($message, $code = 400) {
    api_out(['ok' => false, 'error' => $message], $code);
}

function api_input() {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    return is_array($json) ? array_merge($_POST, $json) : $_POST;
}

/** Returns the authenticated rider row, or exits with 401. */
function api_rider() {
    global $conn;
    $token = '';
    $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (stripos($hdr, 'Bearer ') === 0) $token = trim(substr($hdr, 7));
    if ($token === '') {
        $in = api_input();
        $token = trim($in['token'] ?? '');
    }
    if ($token === '') api_fail('Missing API token.', 401);

    $stmt = $conn->prepare("SELECT * FROM riders WHERE api_token = ? AND status='active'");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $rider = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$rider) api_fail('Invalid or inactive token.', 401);
    return $rider;
}
