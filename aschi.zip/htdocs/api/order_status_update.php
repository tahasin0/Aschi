<?php
/**
 * POST /api/order_status_update.php
 * Body: { "token": "...", "order_id": 12, "status": "picked_up" }
 * A rider may only move an order that is assigned to them, and only
 * to one of the delivery-side statuses.
 */
require_once __DIR__ . '/_api.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') api_fail('POST only.', 405);

$rider = api_rider();
$in    = api_input();

$orderId = (int)($in['order_id'] ?? 0);
$status  = trim($in['status'] ?? '');
$allowed = ['picked_up', 'on_the_way', 'delivered'];

if (!$orderId) api_fail('order_id is required.');
if (!in_array($status, $allowed, true)) api_fail('status must be one of: ' . implode(', ', $allowed));

$stmt = $conn->prepare("SELECT id FROM orders WHERE id = ? AND rider_id = ?");
$stmt->bind_param('ii', $orderId, $rider['id']);
$stmt->execute();
$found = $stmt->get_result()->num_rows;
$stmt->close();
if (!$found) api_fail('Order not found or not assigned to this rider.', 403);

$stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
$stmt->bind_param('si', $status, $orderId);
$stmt->execute();
$stmt->close();

log_status_change($orderId, $status, 'rider:' . $rider['id']);

api_out(['ok' => true, 'order_id' => $orderId, 'status' => $status]);
