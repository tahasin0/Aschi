<?php
/**
 * POST /api/rider_location_update.php
 * Body: { "token": "...", "lat": 22.3569, "lng": 91.7832 }
 * The rider app pushes its current coordinates here; the customer
 * tracking page reads them from the riders table.
 */
require_once __DIR__ . '/_api.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') api_fail('POST only.', 405);

$rider = api_rider();
$in    = api_input();

$lat = isset($in['lat']) ? (float)$in['lat'] : null;
$lng = isset($in['lng']) ? (float)$in['lng'] : null;

if ($lat === null || $lng === null || abs($lat) > 90 || abs($lng) > 180) {
    api_fail('lat and lng are required and must be valid coordinates.');
}

$stmt = $conn->prepare("UPDATE riders SET current_lat=?, current_lng=?, location_updated_at=NOW() WHERE id=?");
$stmt->bind_param('ddi', $lat, $lng, $rider['id']);
$stmt->execute();
$stmt->close();

api_out(['ok' => true, 'rider_id' => (int)$rider['id'], 'lat' => $lat, 'lng' => $lng, 'updated_at' => date('c')]);
