<?php
/**
 * GET /api/order_details.php?order_id=12&token=...
 * Returns the order, its items and the customer contact for the assigned rider.
 * Without order_id it returns the rider's active order list.
 */
require_once __DIR__ . '/_api.php';

$rider = api_rider();
$orderId = (int)($_GET['order_id'] ?? 0);

if (!$orderId) {
    $stmt = $conn->prepare(
        "SELECT id, order_code, guest_name, guest_phone, guest_address, total, order_status, created_at
         FROM orders WHERE rider_id = ? AND order_status NOT IN ('delivered','cancelled') ORDER BY id DESC"
    );
    $stmt->bind_param('i', $rider['id']);
    $stmt->execute();
    $list = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    api_out(['ok' => true, 'orders' => $list]);
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND rider_id = ?");
$stmt->bind_param('ii', $orderId, $rider['id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$order) api_fail('Order not found or not assigned to this rider.', 403);

$stmt = $conn->prepare("SELECT product_name, unit, quantity, price FROM order_items WHERE order_id = ?");
$stmt->bind_param('i', $orderId);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

api_out([
    'ok' => true,
    'order' => [
        'id'            => (int)$order['id'],
        'order_code'    => $order['order_code'],
        'customer_name' => $order['guest_name'],
        'phone'         => $order['guest_phone'],
        'address'       => $order['guest_address'],
        'note'          => $order['note'],
        'subtotal'      => (float)$order['subtotal'],
        'delivery_charge' => (float)$order['delivery_charge'],
        'total'         => (float)$order['total'],
        'payment'       => $order['advance_paid_status'] === 'approved' ? 'advance_paid' : 'cash_on_delivery',
        'status'        => $order['order_status'],
        'created_at'    => $order['created_at'],
    ],
    'items' => $items,
]);
