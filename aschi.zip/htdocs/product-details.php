<?php
require_once __DIR__ . '/includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT p.*, c.name AS cat_name FROM products p
                        LEFT JOIN categories c ON c.id = p.category_id
                        WHERE p.id = ? AND p.status='active'");
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    http_response_code(404);
    $__title = 'পণ্যটি পাওয়া যায়নি — Aschi';
    require_once __DIR__ . '/includes/header.php';
    echo '<main class="container py-5 text-center"><h1 class="h4 fw-bold">পণ্যটি পাওয়া যায়নি</h1>
          <p class="text-muted">এটি সরিয়ে ফেলা হয়েছে বা লিংকটি ভুল।</p>
          <a class="btn btn-green" href="' . url('products.php') . '">সব পণ্য দেখুন</a></main>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Buy Now — add to cart then jump to checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['buy_now'] ?? '') === '1') {
    csrf_check();
    if (!ordering_open()) {
        flash(setting('order_off_message'), 'warning');
        redirect('product-details.php?id=' . $id);
    }
    cart_add($id, (int)($_POST['qty'] ?? 1));
    redirect('checkout.php');
}

$gal = $conn->prepare("SELECT image FROM product_images WHERE product_id = ?");
$gal->bind_param('i', $id);
$gal->execute();
$gallery = $gal->get_result()->fetch_all(MYSQLI_ASSOC);
$gal->close();

$rel = $conn->prepare("SELECT * FROM products WHERE category_id = ? AND id <> ? AND status='active' ORDER BY RAND() LIMIT 4");
$rel->bind_param('ii', $product['category_id'], $id);
$rel->execute();
$related = $rel->get_result();
$rel->close();

$__title = $product['name'] . ' — Aschi';
require_once __DIR__ . '/includes/header.php';
$open = ordering_open();
$inStock = (int)$product['stock'] > 0;
?>

<main class="container py-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb small">
      <li class="breadcrumb-item"><a href="<?= url('index.php') ?>">হোম</a></li>
      <li class="breadcrumb-item"><a href="<?= url('products.php?cat=' . (int)$product['category_id']) ?>"><?= h($product['cat_name']) ?></a></li>
      <li class="breadcrumb-item active"><?= h($product['name']) ?></li>
    </ol>
  </nav>

  <div class="row g-4">
    <div class="col-md-6">
      <div class="card-soft p-2">
        <img id="mainImg" src="<?= product_image($product['image']) ?>" alt="<?= h($product['name']) ?>"
             class="w-100 rounded-3" style="aspect-ratio:1/1;object-fit:cover">
      </div>
      <?php if ($gallery): ?>
      <div class="d-flex gap-2 mt-2 flex-wrap">
        <img class="rounded-3 border" style="width:72px;height:72px;object-fit:cover;cursor:pointer"
             src="<?= product_image($product['image']) ?>" alt="" onclick="document.getElementById('mainImg').src=this.src">
        <?php foreach ($gallery as $g): ?>
          <img class="rounded-3 border" style="width:72px;height:72px;object-fit:cover;cursor:pointer"
               src="<?= product_image($g['image']) ?>" alt="" onclick="document.getElementById('mainImg').src=this.src">
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <div class="col-md-6">
      <span class="badge badge-soft mb-2"><?= h($product['cat_name']) ?></span>
      <h1 class="h3 fw-bold"><?= h($product['name']) ?></h1>

      <div class="my-3">
        <span class="fs-3 fw-bold text-green"><?= taka($product['price']) ?></span>
        <?php if (!empty($product['old_price']) && $product['old_price'] > $product['price']): ?>
          <span class="old-price fs-6"><?= taka($product['old_price']) ?></span>
        <?php endif; ?>
        <span class="text-muted">/ <?= h($product['unit']) ?></span>
      </div>

      <p class="text-muted" style="max-width:60ch"><?= nl2br(h($product['description'])) ?></p>

      <p class="mb-3">
        <?php if ($inStock): ?>
          <span class="badge bg-success-subtle text-success-emphasis">স্টকে আছে (<?= bn_num($product['stock']) ?> <?= h($product['unit']) ?>)</span>
        <?php else: ?>
          <span class="badge bg-danger-subtle text-danger-emphasis">স্টকে নেই</span>
        <?php endif; ?>
      </p>

      <?php if (!$open): ?>
        <div class="notice-bar mb-3"><?= h(setting('order_off_message')) ?></div>
      <?php endif; ?>

      <form method="post" class="d-flex flex-wrap align-items-center gap-2">
        <?= csrf_field() ?>
        <div class="qty-box">
          <button type="button" class="js-qty-step" data-step="-1" aria-label="কমান">−</button>
          <input class="js-qty" name="qty" type="number" value="1" min="1" max="<?= (int)$product['stock'] ?>" inputmode="numeric">
          <button type="button" class="js-qty-step" data-step="1" aria-label="বাড়ান">+</button>
        </div>

        <button type="button" class="btn btn-outline-green px-4 js-add-cart" data-id="<?= (int)$product['id'] ?>"
                <?= ($open && $inStock) ? '' : 'disabled' ?>>
          <i class="bi bi-cart-plus"></i> কার্টে যোগ করুন
        </button>

        <button type="submit" name="buy_now" value="1" class="btn btn-green px-4"
                <?= ($open && $inStock) ? '' : 'disabled' ?>>
          এখনই কিনুন
        </button>
      </form>

      <div class="card-soft p-3 mt-4">
        <div class="d-flex gap-3 align-items-center">
          <span style="font-size:28px">🛵</span>
          <div>
            <div class="fw-semibold">ডেলিভারি চার্জ <?= taka(setting('delivery_charge', 0)) ?></div>
            <div class="text-muted small">
              <?= taka(setting('free_delivery_above', 0)) ?> টাকার বেশি অর্ডারে ডেলিভারি ফ্রি।
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php if ($related->num_rows): ?>
  <section class="mt-5">
    <h2 class="section-title mb-3">একই ক্যাটেগরির পণ্য</h2>
    <div class="row row-cols-2 row-cols-md-4 g-3">
      <?php while ($p = $related->fetch_assoc()): ?>
        <div class="col"><?php include __DIR__ . '/includes/product_card.php'; ?></div>
      <?php endwhile; ?>
    </div>
  </section>
  <?php endif; ?>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
