<?php
require_once __DIR__ . '/includes/functions.php';

$code = trim($_GET['code'] ?? '');
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_code = ?");
$stmt->bind_param('s', $code);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) { flash('অর্ডারটি পাওয়া যায়নি।', 'warning'); redirect('index.php'); }

$__title = 'অর্ডার নেওয়া হয়েছে — Aschi';
require_once __DIR__ . '/includes/header.php';
?>
<main class="container py-5">
  <div class="card-soft p-4 p-md-5 text-center mx-auto" style="max-width:640px">
    <div style="font-size:54px">✅</div>
    <h1 class="h4 fw-bold mt-2">অর্ডার নেওয়া হয়েছে</h1>
    <p class="text-muted">
      আপনার অর্ডার নম্বর <strong class="text-green"><?= h($order['order_code']) ?></strong>।
      নম্বরটি রেখে দিন — এটি দিয়ে যেকোনো সময় অর্ডার ট্র্যাক করতে পারবেন।
    </p>

    <?php if ($order['advance_paid_status'] === 'pending'): ?>
      <div class="notice-bar text-start my-3">
        আপনার পাঠানো TRX ID <strong><?= h($order['trx_id']) ?></strong> যাচাই করা হচ্ছে।
        অ্যাপ্রুভ হওয়ার পর অর্ডার কনফার্ম হবে এবং আমরা ফোনে জানাব।
      </div>
    <?php endif; ?>

    <div class="text-start card-soft p-3 my-3">
      <div class="d-flex justify-content-between"><span class="text-muted">নাম</span><span><?= h($order['guest_name']) ?></span></div>
      <div class="d-flex justify-content-between"><span class="text-muted">ফোন</span><span><?= h($order['guest_phone']) ?></span></div>
      <div class="d-flex justify-content-between"><span class="text-muted">ঠিকানা</span><span class="text-end" style="max-width:60%"><?= h($order['guest_address']) ?></span></div>
      <hr class="my-2">
      <div class="d-flex justify-content-between fw-bold"><span>সর্বমোট</span><span class="text-green"><?= taka($order['total']) ?></span></div>
    </div>

    <div class="d-flex flex-wrap gap-2 justify-content-center">
      <a class="btn btn-green" href="<?= url('track-order.php?code=' . urlencode($order['order_code'])) ?>">অর্ডার ট্র্যাক করুন</a>
      <a class="btn btn-outline-green" href="<?= url('products.php') ?>">আরও কিনুন</a>
    </div>
  </div>
</main>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
