<?php
require_once __DIR__ . '/includes/auth.php';
if (current_admin()) redirect('admin/dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (login_blocked()) {
        $error = 'অনেকবার ভুল চেষ্টা হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন।';
    } else {
        $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ? AND status='active'");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $a = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($a && password_verify($password, $a['password'])) {
            session_regenerate_id(true);
            clear_login_attempts();
            $_SESSION['admin_id'] = $a['id'];
            redirect('admin/dashboard.php');
        }
        record_login_attempt($username);
        $error = 'ইউজারনেম বা পাসওয়ার্ড মিলছে না।';
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>অ্যাডমিন লগইন — Aschi</title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body style="background:#F5F7F6">
<div class="container" style="max-width:400px;padding-top:9vh">
  <div class="text-center mb-3">
    <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi" style="height:78px">
  </div>
  <div class="card-soft p-4">
    <h1 class="h6 fw-bold mb-3">ম্যানেজার প্যানেলে লগইন</h1>
    <?php if ($error): ?><div class="alert alert-danger py-2"><?= h($error) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label" for="username">ইউজারনেম</label>
        <input class="form-control" id="username" name="username" required autofocus>
      </div>
      <div class="mb-3">
        <label class="form-label" for="password">পাসওয়ার্ড</label>
        <input class="form-control" id="password" name="password" type="password" required>
      </div>
      <button class="btn btn-green w-100">লগইন</button>
    </form>
  </div>
  <p class="text-center text-muted small mt-3"><a href="<?= url('index.php') ?>">← সাইটে ফিরে যান</a></p>
</div>
</body>
</html>
