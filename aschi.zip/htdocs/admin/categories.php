<?php
$__title = 'ক্যাটেগরি';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (isset($_POST['save'])) {
        $id     = (int)($_POST['id'] ?? 0);
        $name   = trim($_POST['name']);
        $slug   = trim($_POST['slug']) ?: null;
        $sort   = (int)$_POST['sort_order'];
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
        $icon   = upload_image('icon_image', 'categories');

        if ($name === '') { flash('ক্যাটেগরির নাম দিন।', 'error'); redirect('admin/categories.php'); }

        if ($id) {
            if ($icon) {
                $stmt = $conn->prepare("UPDATE categories SET name=?, slug=?, sort_order=?, status=?, icon_image=? WHERE id=?");
                $stmt->bind_param('ssissi', $name, $slug, $sort, $status, $icon, $id);
            } else {
                $stmt = $conn->prepare("UPDATE categories SET name=?, slug=?, sort_order=?, status=? WHERE id=?");
                $stmt->bind_param('ssisi', $name, $slug, $sort, $status, $id);
            }
            $stmt->execute(); $stmt->close();
            flash('ক্যাটেগরি আপডেট হয়েছে।');
        } else {
            $stmt = $conn->prepare("INSERT INTO categories (name, slug, sort_order, status, icon_image) VALUES (?,?,?,?,?)");
            $stmt->bind_param('ssiss', $name, $slug, $sort, $status, $icon);
            $stmt->execute(); $stmt->close();
            flash('ক্যাটেগরি যোগ হয়েছে।');
        }
        redirect('admin/categories.php');
    }

    if (isset($_POST['delete'])) {
        require_role_admin();
        $id = (int)$_POST['delete'];
        $stmt = $conn->prepare("DELETE FROM categories WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        flash('ক্যাটেগরি মুছে ফেলা হয়েছে। পণ্যগুলো ক্যাটেগরি ছাড়া থেকে গেছে।');
        redirect('admin/categories.php');
    }
}

$edit = null;
if (!empty($_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id=?");
    $stmt->bind_param('i', $_GET['edit']); $stmt->execute();
    $edit = $stmt->get_result()->fetch_assoc(); $stmt->close();
}
$rows = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) pc
                      FROM categories c ORDER BY c.sort_order, c.id");
?>
<h1 class="h4 fw-bold mb-3">ক্যাটেগরি</h1>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-head">
        <h2 class="h6 fw-bold mb-0"><?= $edit ? 'ক্যাটেগরি এডিট' : 'নতুন ক্যাটেগরি' ?></h2>
        <?php if ($edit): ?><a class="btn btn-sm btn-outline-green" href="<?= admin_url('categories.php') ?>">নতুন</a><?php endif; ?>
      </div>
      <div class="panel-body">
        <form method="post" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
          <div class="mb-2">
            <label class="form-label" for="name">নাম</label>
            <input class="form-control" id="name" name="name" value="<?= h($edit['name'] ?? '') ?>" required>
          </div>
          <div class="mb-2">
            <label class="form-label" for="slug">স্লাগ (ইংরেজিতে)</label>
            <input class="form-control" id="slug" name="slug" value="<?= h($edit['slug'] ?? '') ?>" placeholder="sobji">
          </div>
          <div class="mb-2">
            <label class="form-label" for="sort_order">ক্রম</label>
            <input class="form-control" id="sort_order" name="sort_order" type="number" value="<?= (int)($edit['sort_order'] ?? 0) ?>">
          </div>
          <div class="mb-2">
            <label class="form-label" for="icon_image">3D আইকন (PNG/WebP)</label>
            <input class="form-control" id="icon_image" name="icon_image" type="file" accept="image/*">
            <?php if (!empty($edit['icon_image'])): ?>
              <img src="<?= url('assets/images/categories/' . h($edit['icon_image'])) ?>" alt="" width="56" class="mt-2">
            <?php endif; ?>
          </div>
          <div class="mb-3">
            <label class="form-label" for="status">স্ট্যাটাস</label>
            <select class="form-select" id="status" name="status">
              <option value="active" <?= ($edit['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>সক্রিয়</option>
              <option value="inactive" <?= ($edit['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>নিষ্ক্রিয়</option>
            </select>
          </div>
          <button class="btn btn-green w-100" name="save" value="1"><?= $edit ? 'আপডেট করুন' : 'যোগ করুন' ?></button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="panel">
      <table class="table align-middle mb-0">
        <thead class="table-light"><tr><th>আইকন</th><th>নাম</th><th>পণ্য</th><th>অবস্থা</th><th></th></tr></thead>
        <tbody>
        <?php while ($c = $rows->fetch_assoc()): ?>
          <tr>
            <td>
              <?php if ($c['icon_image']): ?>
                <img src="<?= url('assets/images/categories/' . h($c['icon_image'])) ?>" alt="" width="38">
              <?php else: ?><span class="text-muted">—</span><?php endif; ?>
            </td>
            <td class="fw-semibold"><?= h($c['name']) ?><div class="text-muted small"><?= h($c['slug']) ?></div></td>
            <td><?= bn_num($c['pc']) ?></td>
            <td><span class="badge <?= $c['status']==='active'?'bg-success':'bg-secondary' ?>"><?= $c['status']==='active'?'সক্রিয়':'নিষ্ক্রিয়' ?></span></td>
            <td class="text-end">
              <a class="btn btn-sm btn-outline-green" href="<?= admin_url('categories.php?edit=' . (int)$c['id']) ?>"><i class="bi bi-pencil"></i></a>
              <?php if ($admin['role'] === 'admin'): ?>
              <form method="post" class="d-inline" data-confirm="ক্যাটেগরিটি মুছে ফেলবেন?">
                <?= csrf_field() ?>
                <button class="btn btn-sm btn-outline-danger" name="delete" value="<?= (int)$c['id'] ?>"><i class="bi bi-trash"></i></button>
              </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
