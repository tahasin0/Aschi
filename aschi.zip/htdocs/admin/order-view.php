<?php
$__title = 'অর্ডার বিস্তারিত';
require_once __DIR__ . '/includes/admin_header.php';

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)$_POST['order_id'];

    if (isset($_POST['approve_payment']) || isset($_POST['reject_payment'])) {
        $new = isset($_POST['approve_payment']) ? 'approved' : 'rejected';
        $stmt = $conn->prepare("UPDATE orders SET advance_paid_status = ? WHERE id = ?");
        $stmt->bind_param('si', $new, $id);
        $stmt->execute();
        $stmt->close();

        if ($new === 'approved') {
            $stmt = $conn->prepare("UPDATE orders SET order_status='confirmed' WHERE id = ? AND order_status='pending'");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            log_status_change($id, 'confirmed', $admin['username']);
        }
        flash($new === 'approved' ? 'পেমেন্ট অ্যাপ্রুভ হয়েছে।' : 'পেমেন্ট রিজেক্ট করা হয়েছে।');
    }

    if (isset($_POST['set_status'])) {
        $status = $_POST['status'] ?? '';
        if (array_key_exists($status, order_statuses())) {
            $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
            $stmt->bind_param('si', $status, $id);
            $stmt->execute();
            $stmt->close();
            log_status_change($id, $status, $admin['username']);
            flash('স্ট্যাটাস আপডেট হয়েছে।');
        }
    }

    if (isset($_POST['assign_rider'])) {
        $riderId = (int)$_POST['rider_id'] ?: null;
        $stmt = $conn->prepare("UPDATE orders SET rider_id = ?, order_status = IF(order_status IN ('pending','confirmed'),'rider_assigned',order_status) WHERE id = ?");
        $stmt->bind_param('ii', $riderId, $id);
        $stmt->execute();
        $stmt->close();
        log_status_change($id, 'rider_assigned', $admin['username']);
        flash('রাইডার অ্যাসাইন হয়েছে।');
    }
    redirect('admin/order-view.php?id=' . $id);
}

$stmt = $conn->prepare("SELECT o.*, r.name rider_name, r.phone rider_phone FROM orders o
                        LEFT JOIN riders r ON r.id = o.rider_id WHERE o.id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$o = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$o) { flash('অর্ডার পাওয়া যায়নি।', 'error'); redirect('admin/orders.php'); }

$stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stmt = $conn->prepare("SELECT * FROM order_status_history WHERE order_id = ? ORDER BY id DESC");
$stmt->bind_param('i', $id);
$stmt->execute();
$history = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$riders = $conn->query("SELECT id, name FROM riders WHERE status='active' ORDER BY name")->fetch_all(MYSQLI_ASSOC);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h4 fw-bold mb-0">অর্ডার <?= h($o['order_code']) ?></h1>
  <div class="d-flex gap-2">
    <a class="btn btn-green btn-sm" href="<?= admin_url('invoice.php?id=' . (int)$o['id'] . '&print=1') ?>" target="_blank">
      <i class="bi bi-printer"></i> ইনভয়েস প্রিন্ট
    </a>
    <a class="btn btn-outline-green btn-sm" href="<?= admin_url('orders.php') ?>">← সব অর্ডার</a>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="panel mb-3">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">পণ্যের তালিকা</h2></div>
      <div class="table-responsive">
        <table class="table mb-0">
          <thead class="table-light"><tr><th>পণ্য</th><th>পরিমাণ</th><th>দাম</th><th class="text-end">মোট</th></tr></thead>
          <tbody>
          <?php foreach ($items as $it): ?>
            <tr>
              <td><?= h($it['product_name']) ?></td>
              <td><?= bn_num($it['quantity']) ?> <?= h($it['unit']) ?></td>
              <td><?= taka($it['price']) ?></td>
              <td class="text-end"><?= taka($it['quantity'] * $it['price']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr><td colspan="3" class="text-end text-muted">সাবটোটাল</td><td class="text-end"><?= taka($o['subtotal']) ?></td></tr>
            <tr><td colspan="3" class="text-end text-muted">ডেলিভারি চার্জ</td><td class="text-end"><?= taka($o['delivery_charge']) ?></td></tr>
            <tr class="fw-bold"><td colspan="3" class="text-end">সর্বমোট</td><td class="text-end text-green"><?= taka($o['total']) ?></td></tr>
          </tfoot>
        </table>
      </div>
    </div>

    <?php if ($o['advance_paid_status'] !== 'not_required'): ?>
    <div class="panel mb-3">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">অগ্রিম পেমেন্ট যাচাই</h2></div>
      <div class="panel-body">
        <div class="row g-2 mb-3">
          <div class="col-sm-4"><div class="text-muted small">মেথড</div><div><?= h($o['payment_method']) ?></div></div>
          <div class="col-sm-4"><div class="text-muted small">যে নাম্বারে পাঠানো</div><div><?= h($o['payment_number_used']) ?></div></div>
          <div class="col-sm-4"><div class="text-muted small">TRX ID</div><div class="fw-bold fs-5"><?= h($o['trx_id']) ?></div></div>
        </div>
        <p>বর্তমান অবস্থা:
          <span class="badge bg-<?= ['pending'=>'warning text-dark','approved'=>'success','rejected'=>'danger'][$o['advance_paid_status']] ?? 'secondary' ?>">
            <?= h(payment_status_label($o['advance_paid_status'])) ?>
          </span>
        </p>
        <?php if ($o['advance_paid_status'] === 'pending'): ?>
        <form method="post" class="d-flex gap-2" data-confirm="TRX ID যাচাই করে নিশ্চিত করেছেন?">
          <?= csrf_field() ?>
          <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <button class="btn btn-green" name="approve_payment" value="1">অ্যাপ্রুভ করুন</button>
          <button class="btn btn-outline-danger" name="reject_payment" value="1">রিজেক্ট করুন</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="panel">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">স্ট্যাটাস লগ</h2></div>
      <div class="panel-body">
        <?php if (!$history): ?>
          <p class="text-muted mb-0">কোনো লগ নেই।</p>
        <?php else: foreach ($history as $hst): ?>
          <div class="d-flex justify-content-between border-bottom py-2">
            <span><?= h(status_label($hst['status'])) ?></span>
            <span class="text-muted small"><?= h($hst['changed_by']) ?> · <?= date('d M, h:i A', strtotime($hst['created_at'])) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="panel mb-3">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">কাস্টমার</h2></div>
      <div class="panel-body">
        <div class="mb-2"><div class="text-muted small">নাম</div><div><?= h($o['guest_name']) ?></div></div>
        <div class="mb-2"><div class="text-muted small">ফোন</div><a href="tel:<?= h($o['guest_phone']) ?>"><?= h($o['guest_phone']) ?></a></div>
        <div class="mb-2"><div class="text-muted small">ঠিকানা</div><div><?= nl2br(h($o['guest_address'])) ?></div></div>
        <?php if ($o['note']): ?>
          <div><div class="text-muted small">নির্দেশনা</div><div><?= nl2br(h($o['note'])) ?></div></div>
        <?php endif; ?>
        <div class="mt-2"><span class="badge badge-soft"><?= $o['user_id'] ? 'রেজিস্টার্ড কাস্টমার' : 'গেস্ট অর্ডার' ?></span></div>
      </div>
    </div>

    <div class="panel mb-3">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">স্ট্যাটাস ও রাইডার</h2></div>
      <div class="panel-body">
        <form method="post" class="mb-3">
          <?= csrf_field() ?>
          <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <label class="form-label" for="status">অর্ডার স্ট্যাটাস</label>
          <div class="d-flex gap-2">
            <select class="form-select" id="status" name="status">
              <?php foreach (order_statuses() as $k => $v): ?>
                <option value="<?= $k ?>" <?= $o['order_status'] === $k ? 'selected' : '' ?>><?= $v ?></option>
              <?php endforeach; ?>
            </select>
            <button class="btn btn-green" name="set_status" value="1">সেভ</button>
          </div>
        </form>

        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <label class="form-label" for="rider_id">রাইডার</label>
          <div class="d-flex gap-2">
            <select class="form-select" id="rider_id" name="rider_id">
              <option value="0">— রাইডার নেই —</option>
              <?php foreach ($riders as $r): ?>
                <option value="<?= (int)$r['id'] ?>" <?= (int)$o['rider_id'] === (int)$r['id'] ? 'selected' : '' ?>><?= h($r['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <button class="btn btn-green" name="assign_rider" value="1">অ্যাসাইন</button>
          </div>
        </form>

        <?php if ($o['rider_name']): ?>
          <p class="text-muted small mt-3 mb-0">
            বর্তমান রাইডার: <?= h($o['rider_name']) ?> (<?= h($o['rider_phone']) ?>)
          </p>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
