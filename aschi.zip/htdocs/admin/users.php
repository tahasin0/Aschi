<?php
$__title = 'কাস্টমার';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['toggle'])) {
        $id = (int)$_POST['toggle'];
        $stmt = $conn->prepare("UPDATE users SET status = IF(status='active','blocked','active') WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        flash('কাস্টমারের অবস্থা বদলানো হয়েছে।');
        redirect('admin/users.php');
    }
}

$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $stmt = $conn->prepare("SELECT * FROM users WHERE name LIKE ? OR phone LIKE ? ORDER BY id DESC");
    $like = "%$q%"; $stmt->bind_param('ss', $like, $like); $stmt->execute();
    $rows = $stmt->get_result(); $stmt->close();
} else {
    $rows = $conn->query("SELECT * FROM users ORDER BY id DESC LIMIT 200");
}

$view = null; $orders = null;
if (!empty($_GET['view'])) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
    $stmt->bind_param('i', $_GET['view']); $stmt->execute();
    $view = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if ($view) {
        $stmt = $conn->prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC");
        $stmt->bind_param('i', $view['id']); $stmt->execute();
        $orders = $stmt->get_result(); $stmt->close();
    }
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 fw-bold mb-0">কাস্টমার</h1>
  <form class="d-flex gap-2" method="get">
    <input class="form-control form-control-sm" name="q" value="<?= h($q) ?>" placeholder="নাম বা ফোন">
    <button class="btn btn-sm btn-outline-green">খুঁজুন</button>
  </form>
</div>

<?php if ($view): ?>
<div class="panel mb-3">
  <div class="panel-head">
    <h2 class="h6 fw-bold mb-0"><?= h($view['name']) ?> — অর্ডার হিস্টোরি</h2>
    <a class="btn btn-sm btn-outline-green" href="<?= admin_url('users.php') ?>">বন্ধ করুন</a>
  </div>
  <div class="table-responsive">
    <table class="table mb-0">
      <thead class="table-light"><tr><th>অর্ডার</th><th>তারিখ</th><th>মোট</th><th>স্ট্যাটাস</th><th></th></tr></thead>
      <tbody>
      <?php while ($o = $orders->fetch_assoc()): ?>
        <tr>
          <td class="fw-semibold"><?= h($o['order_code']) ?></td>
          <td class="small text-muted"><?= date('d M Y', strtotime($o['created_at'])) ?></td>
          <td><?= taka($o['total']) ?></td>
          <td><span class="badge bg-<?= status_color($o['order_status']) ?>"><?= h(status_label($o['order_status'])) ?></span></td>
          <td class="text-end"><a class="btn btn-sm btn-outline-green" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>">দেখুন</a></td>
        </tr>
      <?php endwhile; ?>
      <?php if (!$orders->num_rows): ?><tr><td colspan="5" class="text-center text-muted py-3">কোনো অর্ডার নেই।</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="panel">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light"><tr><th>নাম</th><th>ফোন</th><th>ঠিকানা</th><th>যোগদান</th><th>অবস্থা</th><th></th></tr></thead>
      <tbody>
      <?php while ($u = $rows->fetch_assoc()): ?>
        <tr>
          <td class="fw-semibold"><?= h($u['name']) ?></td>
          <td><?= h($u['phone']) ?></td>
          <td class="small text-muted" style="max-width:260px"><?= h(mb_substr($u['address'] ?? '', 0, 60)) ?></td>
          <td class="small text-muted"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          <td>
            <form method="post" class="d-inline"><?= csrf_field() ?>
              <button class="btn btn-sm <?= $u['status']==='active'?'btn-green':'btn-outline-danger' ?>" name="toggle" value="<?= (int)$u['id'] ?>">
                <?= $u['status']==='active'?'সক্রিয়':'ব্লকড' ?>
              </button>
            </form>
          </td>
          <td class="text-end"><a class="btn btn-sm btn-outline-green" href="<?= admin_url('users.php?view=' . (int)$u['id']) ?>">অর্ডার দেখুন</a></td>
        </tr>
      <?php endwhile; ?>
      <?php if (!$rows->num_rows): ?><tr><td colspan="6" class="text-center text-muted py-4">কোনো কাস্টমার নেই।</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
