<?php
$__title = 'পেমেন্ট অ্যাপ্রুভাল';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id  = (int)$_POST['order_id'];
    $new = isset($_POST['approve']) ? 'approved' : 'rejected';

    $stmt = $conn->prepare("UPDATE orders SET advance_paid_status = ? WHERE id = ?");
    $stmt->bind_param('si', $new, $id);
    $stmt->execute();
    $stmt->close();

    if ($new === 'approved') {
        $stmt = $conn->prepare("UPDATE orders SET order_status='confirmed' WHERE id = ? AND order_status='pending'");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        log_status_change($id, 'confirmed', $admin['username']);
    }
    flash($new === 'approved' ? 'পেমেন্ট অ্যাপ্রুভ হয়েছে।' : 'পেমেন্ট রিজেক্ট করা হয়েছে।');
    redirect('admin/payments.php');
}

$filter = $_GET['s'] ?? 'pending';
$allowed = ['pending', 'approved', 'rejected'];
if (!in_array($filter, $allowed, true)) $filter = 'pending';

$stmt = $conn->prepare("SELECT * FROM orders WHERE advance_paid_status = ? ORDER BY id DESC LIMIT 100");
$stmt->bind_param('s', $filter);
$stmt->execute();
$rows = $stmt->get_result();
$stmt->close();
?>

<h1 class="h4 fw-bold mb-3">পেমেন্ট অ্যাপ্রুভাল</h1>

<ul class="nav nav-pills mb-3">
  <?php foreach (['pending' => 'পেন্ডিং', 'approved' => 'অ্যাপ্রুভড', 'rejected' => 'রিজেক্টেড'] as $k => $v): ?>
    <li class="nav-item">
      <a class="nav-link <?= $filter === $k ? 'active' : '' ?>" style="<?= $filter === $k ? 'background:var(--green)' : '' ?>"
         href="<?= admin_url('payments.php?s=' . $k) ?>"><?= $v ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="panel">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light">
        <tr><th>অর্ডার</th><th>কাস্টমার</th><th>TRX ID</th><th>যে নাম্বারে</th><th>চার্জ</th><th></th></tr>
      </thead>
      <tbody>
      <?php while ($o = $rows->fetch_assoc()): ?>
        <tr>
          <td>
            <a class="fw-semibold text-reset" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>"><?= h($o['order_code']) ?></a>
            <div class="text-muted small"><?= date('d M, h:i A', strtotime($o['created_at'])) ?></div>
          </td>
          <td><?= h($o['guest_name']) ?><div class="text-muted small"><?= h($o['guest_phone']) ?></div></td>
          <td class="fw-bold"><?= h($o['trx_id']) ?></td>
          <td><?= h($o['payment_number_used']) ?></td>
          <td><?= taka($o['delivery_charge']) ?></td>
          <td class="text-end">
            <?php if ($filter === 'pending'): ?>
              <form method="post" class="d-inline-flex gap-1" data-confirm="TRX ID যাচাই করে নিশ্চিত করেছেন?">
                <?= csrf_field() ?>
                <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
                <button class="btn btn-sm btn-green" name="approve" value="1">অ্যাপ্রুভ</button>
                <button class="btn btn-sm btn-outline-danger" name="reject" value="1">রিজেক্ট</button>
              </form>
            <?php else: ?>
              <a class="btn btn-sm btn-outline-green" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>">দেখুন</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
      <?php if (!$rows->num_rows): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">এই তালিকায় কিছু নেই।</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
