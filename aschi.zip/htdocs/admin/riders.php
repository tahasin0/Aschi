<?php
$__title = 'রাইডার ম্যানেজমেন্ট';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (isset($_POST['save'])) {
        $id     = (int)($_POST['id'] ?? 0);
        $name   = trim($_POST['name']);
        $phone  = trim($_POST['phone']);
        $social = trim($_POST['social_link']) ?: null;
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
        $photo  = upload_image('photo', 'riders');

        if ($name === '' || !valid_bd_phone($phone)) {
            flash('রাইডারের নাম ও সঠিক ফোন নাম্বার দিন।', 'error');
            redirect('admin/riders.php');
        }

        if ($id) {
            if ($photo) {
                $stmt = $conn->prepare("UPDATE riders SET name=?, phone=?, social_link=?, status=?, photo=? WHERE id=?");
                $stmt->bind_param('sssssi', $name, $phone, $social, $status, $photo, $id);
            } else {
                $stmt = $conn->prepare("UPDATE riders SET name=?, phone=?, social_link=?, status=? WHERE id=?");
                $stmt->bind_param('ssssi', $name, $phone, $social, $status, $id);
            }
            $stmt->execute(); $stmt->close();
            flash('রাইডার আপডেট হয়েছে।');
        } else {
            $token = bin2hex(random_bytes(24));   // used later by the rider app API
            $stmt = $conn->prepare("INSERT INTO riders (name, phone, social_link, status, photo, api_token) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('ssssss', $name, $phone, $social, $status, $photo, $token);
            $stmt->execute(); $stmt->close();
            flash('নতুন রাইডার যোগ হয়েছে।');
        }
        redirect('admin/riders.php');
    }

    if (isset($_POST['toggle'])) {
        $id = (int)$_POST['toggle'];
        $stmt = $conn->prepare("UPDATE riders SET status = IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        flash('রাইডারের অবস্থা বদলানো হয়েছে।');
        redirect('admin/riders.php');
    }

    if (isset($_POST['delete'])) {
        require_role_admin();
        $id = (int)$_POST['delete'];
        $stmt = $conn->prepare("SELECT photo FROM riders WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($row) delete_image($row['photo'], 'riders');
        $stmt = $conn->prepare("DELETE FROM riders WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        flash('রাইডার মুছে ফেলা হয়েছে।');
        redirect('admin/riders.php');
    }
}

$edit = null;
if (!empty($_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM riders WHERE id=?");
    $stmt->bind_param('i', $_GET['edit']); $stmt->execute();
    $edit = $stmt->get_result()->fetch_assoc(); $stmt->close();
}
$rows = $conn->query("SELECT r.*, (SELECT COUNT(*) FROM orders o WHERE o.rider_id=r.id AND o.order_status NOT IN ('delivered','cancelled')) active_orders
                      FROM riders r ORDER BY r.status, r.name");
?>
<h1 class="h4 fw-bold mb-3">রাইডার ম্যানেজমেন্ট</h1>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-head">
        <h2 class="h6 fw-bold mb-0"><?= $edit ? 'রাইডার এডিট' : 'নতুন রাইডার' ?></h2>
        <?php if ($edit): ?><a class="btn btn-sm btn-outline-green" href="<?= admin_url('riders.php') ?>">নতুন</a><?php endif; ?>
      </div>
      <div class="panel-body">
        <form method="post" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
          <div class="mb-2">
            <label class="form-label" for="name">নাম</label>
            <input class="form-control" id="name" name="name" value="<?= h($edit['name'] ?? '') ?>" required>
          </div>
          <div class="mb-2">
            <label class="form-label" for="phone">ফোন নাম্বার</label>
            <input class="form-control" id="phone" name="phone" value="<?= h($edit['phone'] ?? '') ?>" placeholder="01XXXXXXXXX" required>
          </div>
          <div class="mb-2">
            <label class="form-label" for="social_link">সোশ্যাল লিংক</label>
            <input class="form-control" id="social_link" name="social_link" value="<?= h($edit['social_link'] ?? '') ?>" placeholder="https://facebook.com/...">
            <div class="form-text">কাস্টমার ট্র্যাকিং পেজে এই লিংক দেখতে পাবে।</div>
          </div>
          <div class="mb-2">
            <label class="form-label" for="photo">ছবি</label>
            <input class="form-control" id="photo" name="photo" type="file" accept="image/*">
            <?php if (!empty($edit['photo'])): ?>
              <img src="<?= url('assets/images/riders/' . h($edit['photo'])) ?>" alt="" width="56" height="56" class="rounded-circle mt-2" style="object-fit:cover">
            <?php endif; ?>
          </div>
          <div class="mb-3">
            <label class="form-label" for="status">স্ট্যাটাস</label>
            <select class="form-select" id="status" name="status">
              <option value="active" <?= ($edit['status'] ?? 'active')==='active'?'selected':'' ?>>অ্যাক্টিভ</option>
              <option value="inactive" <?= ($edit['status'] ?? '')==='inactive'?'selected':'' ?>>ইনঅ্যাক্টিভ</option>
            </select>
          </div>
          <button class="btn btn-green w-100" name="save" value="1"><?= $edit ? 'আপডেট করুন' : 'রাইডার যোগ করুন' ?></button>
        </form>

        <?php if ($edit && $edit['api_token']): ?>
          <hr>
          <label class="form-label">রাইডার অ্যাপ API টোকেন</label>
          <input class="form-control form-control-sm" value="<?= h($edit['api_token']) ?>" readonly onclick="this.select()">
          <div class="form-text">ভবিষ্যতের রাইডার অ্যাপ এই টোকেন দিয়ে লোকেশন ও স্ট্যাটাস পাঠাবে।</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="panel">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light"><tr><th>রাইডার</th><th>চলমান অর্ডার</th><th>সর্বশেষ লোকেশন</th><th>অবস্থা</th><th></th></tr></thead>
          <tbody>
          <?php while ($r = $rows->fetch_assoc()): ?>
            <tr>
              <td>
                <div class="d-flex gap-2 align-items-center">
                  <img src="<?= $r['photo'] ? url('assets/images/riders/' . h($r['photo'])) : url('assets/images/logo.png') ?>"
                       alt="" width="42" height="42" class="rounded-circle" style="object-fit:cover">
                  <div>
                    <div class="fw-semibold"><?= h($r['name']) ?></div>
                    <a class="text-muted small" href="tel:<?= h($r['phone']) ?>"><?= h($r['phone']) ?></a>
                  </div>
                </div>
              </td>
              <td><?= bn_num($r['active_orders']) ?></td>
              <td class="small text-muted">
                <?php if ($r['current_lat']): ?>
                  <?= h($r['current_lat']) ?>, <?= h($r['current_lng']) ?><br>
                  <?= $r['location_updated_at'] ? date('d M, h:i A', strtotime($r['location_updated_at'])) : '' ?>
                <?php else: ?>—<?php endif; ?>
              </td>
              <td>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?>
                  <button class="btn btn-sm <?= $r['status']==='active'?'btn-green':'btn-outline-danger' ?>" name="toggle" value="<?= (int)$r['id'] ?>">
                    <?= $r['status']==='active'?'অ্যাক্টিভ':'ইনঅ্যাক্টিভ' ?>
                  </button>
                </form>
              </td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-green" href="<?= admin_url('riders.php?edit=' . (int)$r['id']) ?>"><i class="bi bi-pencil"></i></a>
                <?php if ($admin['role'] === 'admin'): ?>
                <form method="post" class="d-inline" data-confirm="রাইডার মুছে ফেলবেন?">
                  <?= csrf_field() ?>
                  <button class="btn btn-sm btn-outline-danger" name="delete" value="<?= (int)$r['id'] ?>"><i class="bi bi-trash"></i></button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
          <?php if (!$rows->num_rows): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">এখনো কোনো রাইডার যোগ করা হয়নি।</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
