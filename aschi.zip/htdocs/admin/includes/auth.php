<?php
/** Admin session guard — include at the top of every admin page except login. */
require_once __DIR__ . '/../../includes/functions.php';

function current_admin() {
    global $conn;
    if (empty($_SESSION['admin_id'])) return null;
    static $admin = null;
    if ($admin === null) {
        $stmt = $conn->prepare("SELECT * FROM admins WHERE id = ? AND status='active'");
        $stmt->bind_param('i', $_SESSION['admin_id']);
        $stmt->execute();
        $admin = $stmt->get_result()->fetch_assoc() ?: null;
        $stmt->close();
    }
    return $admin;
}

function require_admin() {
    if (!current_admin()) redirect('admin/login.php');
}

/** Only the 'admin' role may touch settings, admins and deletions. */
function require_role_admin() {
    $a = current_admin();
    if (!$a || $a['role'] !== 'admin') {
        http_response_code(403);
        die('এই পাতায় প্রবেশের অনুমতি নেই।');
    }
}

function admin_url($path = '') {
    return url('admin/' . ltrim($path, '/'));
}
