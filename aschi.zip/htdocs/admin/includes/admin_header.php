<?php
require_once __DIR__ . '/auth.php';
require_admin();
$admin = current_admin();
$page  = basename($_SERVER['PHP_SELF']);

// Counts for sidebar badges
$pendingOrders = (int)$conn->query("SELECT COUNT(*) c FROM orders WHERE order_status='pending'")->fetch_assoc()['c'];
$pendingPay    = (int)$conn->query("SELECT COUNT(*) c FROM orders WHERE advance_paid_status='pending'")->fetch_assoc()['c'];

$nav = [
  'dashboard.php' => ['ড্যাশবোর্ড', 'speedometer2', 0],
  'orders.php'    => ['অর্ডার', 'receipt', $pendingOrders],
  'payments.php'  => ['পেমেন্ট অ্যাপ্রুভাল', 'cash-coin', $pendingPay],
  'products.php'  => ['পণ্য', 'box-seam', 0],
  'categories.php'=> ['ক্যাটেগরি', 'grid', 0],
  'riders.php'    => ['রাইডার', 'bicycle', 0],
  'banners.php'   => ['ব্যানার', 'images', 0],
  'users.php'     => ['কাস্টমার', 'people', 0],
  'settings.php'  => ['সেটিংস', 'gear', 0],
  'admins.php'    => ['অ্যাডমিন', 'shield-lock', 0],
];
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($__title ?? 'অ্যাডমিন প্যানেল') ?> — Aschi</title>
<link rel="icon" href="<?= url('assets/images/logo.png') ?>">
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
<link href="<?= url('assets/css/admin.css') ?>" rel="stylesheet">
</head>
<body class="admin-body">

<nav class="admin-topbar">
  <button class="btn btn-sm btn-outline-green d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#adminNav" aria-label="মেনু">
    <i class="bi bi-list"></i>
  </button>
  <a href="<?= admin_url('dashboard.php') ?>" class="d-flex align-items-center gap-2">
    <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi" style="height:34px">
    <span class="fw-bold">ম্যানেজার প্যানেল</span>
  </a>
  <div class="ms-auto d-flex align-items-center gap-2">
    <a class="btn btn-sm btn-outline-green" href="<?= url('index.php') ?>" target="_blank"><i class="bi bi-box-arrow-up-right"></i> সাইট দেখুন</a>
    <div class="dropdown">
      <button class="btn btn-sm btn-green dropdown-toggle" data-bs-toggle="dropdown"><?= h($admin['name'] ?: $admin['username']) ?></button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><span class="dropdown-item-text small text-muted"><?= $admin['role'] === 'admin' ? 'সুপার অ্যাডমিন' : 'ম্যানেজার' ?></span></li>
        <li><a class="dropdown-item" href="<?= admin_url('logout.php') ?>">লগ আউট</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="admin-shell">
  <aside class="admin-sidebar offcanvas-lg offcanvas-start" id="adminNav" tabindex="-1">
    <div class="offcanvas-header d-lg-none">
      <h5 class="offcanvas-title">মেনু</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#adminNav"></button>
    </div>
    <div class="offcanvas-body d-block p-0">
      <ul class="admin-nav">
        <?php foreach ($nav as $file => [$label, $icon, $count]): ?>
          <li>
            <a href="<?= admin_url($file) ?>" class="<?= $page === $file ? 'active' : '' ?>">
              <i class="bi bi-<?= $icon ?>"></i> <span><?= $label ?></span>
              <?php if ($count): ?><span class="badge bg-danger ms-auto"><?= bn_num($count) ?></span><?php endif; ?>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </aside>

  <main class="admin-main">
    <?php if ($__f = flash()): ?>
      <div class="alert alert-<?= $__f['type'] === 'error' ? 'danger' : $__f['type'] ?>"><?= h($__f['msg']) ?></div>
    <?php endif; ?>
