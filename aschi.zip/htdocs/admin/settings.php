<?php
$__title = 'সেটিংস';
require_once __DIR__ . '/includes/auth.php';
require_admin();
require_role_admin();
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (isset($_POST['save_order'])) {
        save_setting('order_status_global', isset($_POST['order_on']) ? 'on' : 'off');
        save_setting('order_off_message', trim($_POST['order_off_message']));
        flash('অর্ডার সেটিংস সেভ হয়েছে।');
    }

    if (isset($_POST['save_payment'])) {
        save_setting('advance_charge_enabled', isset($_POST['advance_enabled']) ? '1' : '0');
        save_setting('advance_charge_amount', (string)max(0, (float)$_POST['advance_amount']));
        save_setting('payment_number', trim($_POST['payment_number']));
        save_setting('payment_method_name', trim($_POST['payment_method_name']));
        save_setting('delivery_charge', (string)max(0, (float)$_POST['delivery_charge']));
        save_setting('free_delivery_above', (string)max(0, (float)$_POST['free_delivery_above']));
        flash('পেমেন্ট ও ডেলিভারি সেটিংস সেভ হয়েছে।');
    }

    if (isset($_POST['save_support'])) {
        save_setting('support_link', trim($_POST['support_link']));
        save_setting('support_phone', trim($_POST['support_phone']));
        save_setting('contact_address', trim($_POST['contact_address']));
        save_setting('google_maps_key', trim($_POST['google_maps_key']));
        save_setting('loader_enabled', isset($_POST['loader_enabled']) ? '1' : '0');
        flash('সাপোর্ট ও সাইট সেটিংস সেভ হয়েছে।');
    }
    redirect('admin/settings.php');
}
?>
<h1 class="h4 fw-bold mb-3">সেটিংস</h1>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="panel mb-3">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">অর্ডার অন / অফ</h2></div>
      <div class="panel-body">
        <form method="post">
          <?= csrf_field() ?>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" role="switch" id="order_on" name="order_on" <?= ordering_open() ? 'checked' : '' ?>>
            <label class="form-check-label fw-semibold" for="order_on">অর্ডার নেওয়া চালু আছে</label>
            <div class="form-text">বন্ধ করলে সাইটে নোটিশ দেখাবে এবং কার্ট/অর্ডার বাটন কাজ করবে না।</div>
          </div>
          <div class="mb-3">
            <label class="form-label" for="order_off_message">বন্ধ থাকার বার্তা</label>
            <textarea class="form-control" id="order_off_message" name="order_off_message" rows="2"><?= h(setting('order_off_message')) ?></textarea>
          </div>
          <button class="btn btn-green" name="save_order" value="1">সেভ করুন</button>
        </form>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">পেমেন্ট ও ডেলিভারি</h2></div>
      <div class="panel-body">
        <form method="post">
          <?= csrf_field() ?>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" role="switch" id="advance_enabled" name="advance_enabled"
                   <?= setting('advance_charge_enabled','0') === '1' ? 'checked' : '' ?>>
            <label class="form-check-label fw-semibold" for="advance_enabled">অগ্রিম ডেলিভারি চার্জ নেব</label>
            <div class="form-text">চালু থাকলে চেকআউটে ম্যানুয়াল পেমেন্ট ও TRX ID ধাপ দেখাবে। বন্ধ থাকলে সরাসরি ক্যাশ অন ডেলিভারি।</div>
          </div>

          <div class="row g-2 mb-2">
            <div class="col-sm-6">
              <label class="form-label" for="advance_amount">অগ্রিম চার্জের পরিমাণ (৳)</label>
              <input class="form-control" id="advance_amount" name="advance_amount" type="number" step="1"
                     value="<?= h(setting('advance_charge_amount', 0)) ?>">
            </div>
            <div class="col-sm-6">
              <label class="form-label" for="payment_method_name">পেমেন্ট মেথডের নাম</label>
              <input class="form-control" id="payment_method_name" name="payment_method_name"
                     value="<?= h(setting('payment_method_name')) ?>" placeholder="বিকাশ / নগদ / রকেট">
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="payment_number">পেমেন্ট নাম্বার</label>
            <input class="form-control" id="payment_number" name="payment_number" value="<?= h(setting('payment_number')) ?>">
            <div class="form-text">এই নাম্বারটি চেকআউট পেজে কাস্টমারকে দেখানো হবে।</div>
          </div>

          <hr>

          <div class="row g-2 mb-3">
            <div class="col-sm-6">
              <label class="form-label" for="delivery_charge">সাধারণ ডেলিভারি চার্জ (৳)</label>
              <input class="form-control" id="delivery_charge" name="delivery_charge" type="number" step="1"
                     value="<?= h(setting('delivery_charge', 0)) ?>">
            </div>
            <div class="col-sm-6">
              <label class="form-label" for="free_delivery_above">এই অংকের উপরে ফ্রি (৳)</label>
              <input class="form-control" id="free_delivery_above" name="free_delivery_above" type="number" step="1"
                     value="<?= h(setting('free_delivery_above', 0)) ?>">
              <div class="form-text">০ দিলে ফ্রি ডেলিভারি বন্ধ থাকবে।</div>
            </div>
          </div>

          <button class="btn btn-green" name="save_payment" value="1">সেভ করুন</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">সাপোর্ট ও সাইট</h2></div>
      <div class="panel-body">
        <form method="post">
          <?= csrf_field() ?>
          <div class="mb-2">
            <label class="form-label" for="support_link">ফ্লোটিং সাপোর্ট লিংক</label>
            <input class="form-control" id="support_link" name="support_link" value="<?= h(setting('support_link')) ?>"
                   placeholder="https://wa.me/8801XXXXXXXXX অথবা m.me/pagename">
            <div class="form-text">খালি রাখলে ফ্লোটিং বাটন দেখাবে না।</div>
          </div>
          <div class="mb-2">
            <label class="form-label" for="support_phone">সাপোর্ট ফোন নাম্বার</label>
            <input class="form-control" id="support_phone" name="support_phone" value="<?= h(setting('support_phone')) ?>">
          </div>
          <div class="mb-2">
            <label class="form-label" for="contact_address">ঠিকানা (ফুটারে দেখাবে)</label>
            <input class="form-control" id="contact_address" name="contact_address" value="<?= h(setting('contact_address')) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label" for="google_maps_key">Google Maps API Key</label>
            <input class="form-control" id="google_maps_key" name="google_maps_key" value="<?= h(setting('google_maps_key')) ?>">
            <div class="form-text">খালি থাকলে ট্র্যাকিং পেজে সাধারণ এমবেড ম্যাপ দেখাবে।</div>
          </div>
          <div class="form-check form-switch mb-3">
            <input class="form-check-input" type="checkbox" role="switch" id="loader_enabled" name="loader_enabled"
                   <?= setting('loader_enabled','1') === '1' ? 'checked' : '' ?>>
            <label class="form-check-label fw-semibold" for="loader_enabled">লোডিং অ্যানিমেশন দেখাব</label>
          </div>
          <button class="btn btn-green" name="save_support" value="1">সেভ করুন</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
