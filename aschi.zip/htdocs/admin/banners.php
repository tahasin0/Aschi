<?php
$__title = 'ব্যানার ম্যানেজমেন্ট';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (isset($_POST['save_text'])) {
        save_setting('banner_text', trim($_POST['banner_text']));
        save_setting('banner_speed', (string)max(5, (int)$_POST['banner_speed']));
        save_setting('banner_direction', $_POST['banner_direction'] === 'right' ? 'right' : 'left');
        flash('স্ক্রলিং ব্যানার আপডেট হয়েছে।');
        redirect('admin/banners.php');
    }

    if (isset($_POST['add_banner'])) {
        $image = upload_image('image', 'banners');
        if (!$image) { flash('ছবি আপলোড হয়নি — JPG/PNG/WebP, সর্বোচ্চ ৪ এমবি।', 'error'); redirect('admin/banners.php'); }
        $link = trim($_POST['link']) ?: null;
        $sort = (int)$_POST['sort_order'];
        $stmt = $conn->prepare("INSERT INTO banners (image, link, sort_order) VALUES (?,?,?)");
        $stmt->bind_param('ssi', $image, $link, $sort);
        $stmt->execute(); $stmt->close();
        flash('ব্যানার যোগ হয়েছে।');
        redirect('admin/banners.php');
    }

    if (isset($_POST['delete'])) {
        $id = (int)$_POST['delete'];
        $stmt = $conn->prepare("SELECT image FROM banners WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($row) delete_image($row['image'], 'banners');
        $stmt = $conn->prepare("DELETE FROM banners WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        flash('ব্যানার মুছে ফেলা হয়েছে।');
        redirect('admin/banners.php');
    }

    if (isset($_POST['toggle'])) {
        $id = (int)$_POST['toggle'];
        $stmt = $conn->prepare("UPDATE banners SET status = IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        redirect('admin/banners.php');
    }
}

$rows = $conn->query("SELECT * FROM banners ORDER BY sort_order, id");
?>
<h1 class="h4 fw-bold mb-3">ব্যানার ম্যানেজমেন্ট</h1>

<div class="panel mb-3">
  <div class="panel-head"><h2 class="h6 fw-bold mb-0">স্ক্রলিং টেক্সট ব্যানার</h2></div>
  <div class="panel-body">
    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-2">
        <label class="form-label" for="banner_text">ব্যানারের লেখা</label>
        <textarea class="form-control" id="banner_text" name="banner_text" rows="2"><?= h(setting('banner_text')) ?></textarea>
        <div class="form-text">খালি রাখলে হোমপেজে ব্যানারটি দেখাবে না।</div>
      </div>
      <div class="row g-2">
        <div class="col-sm-4">
          <label class="form-label" for="banner_speed">এক চক্র শেষ হতে সময় (সেকেন্ড)</label>
          <input class="form-control" id="banner_speed" name="banner_speed" type="number" min="5" value="<?= (int)setting('banner_speed', 35) ?>">
          <div class="form-text">সংখ্যা কমালে দ্রুত চলবে।</div>
        </div>
        <div class="col-sm-4">
          <label class="form-label" for="banner_direction">দিক</label>
          <select class="form-select" id="banner_direction" name="banner_direction">
            <option value="left"  <?= setting('banner_direction','left')==='left'?'selected':'' ?>>ডান থেকে বামে</option>
            <option value="right" <?= setting('banner_direction','left')==='right'?'selected':'' ?>>বাম থেকে ডানে</option>
          </select>
        </div>
        <div class="col-sm-4 d-flex align-items-end">
          <button class="btn btn-green w-100" name="save_text" value="1">সেভ করুন</button>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">নতুন স্লাইডার ব্যানার</h2></div>
      <div class="panel-body">
        <form method="post" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <div class="mb-2">
            <label class="form-label" for="image">ছবি (প্রস্তাবিত ১২০০×৪০০)</label>
            <input class="form-control" id="image" name="image" type="file" accept="image/*" required>
          </div>
          <div class="mb-2">
            <label class="form-label" for="link">লিংক (ঐচ্ছিক)</label>
            <input class="form-control" id="link" name="link" placeholder="https://...">
          </div>
          <div class="mb-3">
            <label class="form-label" for="sort_order">ক্রম</label>
            <input class="form-control" id="sort_order" name="sort_order" type="number" value="0">
          </div>
          <button class="btn btn-green w-100" name="add_banner" value="1">ব্যানার যোগ করুন</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="panel panel-body">
      <?php if (!$rows->num_rows): ?>
        <p class="text-muted mb-0">কোনো স্লাইডার ব্যানার নেই। ব্যানার না থাকলে হোমপেজে ডিফল্ট হিরো সেকশন দেখাবে।</p>
      <?php else: ?>
        <div class="row g-3">
        <?php while ($b = $rows->fetch_assoc()): ?>
          <div class="col-md-6">
            <div class="border rounded-3 overflow-hidden">
              <img src="<?= url('assets/images/banners/' . h($b['image'])) ?>" alt="" class="w-100" style="max-height:130px;object-fit:cover">
              <div class="p-2 d-flex align-items-center justify-content-between">
                <span class="badge <?= $b['status']==='active'?'bg-success':'bg-secondary' ?>"><?= $b['status']==='active'?'সক্রিয়':'নিষ্ক্রিয়' ?></span>
                <div class="d-flex gap-1">
                  <form method="post"><?= csrf_field() ?><button class="btn btn-sm btn-outline-green" name="toggle" value="<?= (int)$b['id'] ?>">টগল</button></form>
                  <form method="post" data-confirm="ব্যানারটি মুছে ফেলবেন?"><?= csrf_field() ?>
                    <button class="btn btn-sm btn-outline-danger" name="delete" value="<?= (int)$b['id'] ?>"><i class="bi bi-trash"></i></button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
