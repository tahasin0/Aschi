<?php
$__title = 'অর্ডার ম্যানেজমেন্ট';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $orderId = (int)($_POST['order_id'] ?? 0);

    if (isset($_POST['set_status'])) {
        $status = $_POST['status'] ?? '';
        if (!array_key_exists($status, order_statuses())) { flash('স্ট্যাটাস সঠিক নয়।', 'error'); redirect('admin/orders.php'); }

        $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
        $stmt->bind_param('si', $status, $orderId);
        $stmt->execute();
        $stmt->close();
        log_status_change($orderId, $status, $admin['username']);
        flash('অর্ডার স্ট্যাটাস আপডেট হয়েছে।');
    }

    if (isset($_POST['assign_rider'])) {
        $riderId = (int)$_POST['rider_id'] ?: null;
        $stmt = $conn->prepare("UPDATE orders SET rider_id = ?, order_status = IF(order_status IN ('pending','confirmed'),'rider_assigned',order_status) WHERE id = ?");
        $stmt->bind_param('ii', $riderId, $orderId);
        $stmt->execute();
        $stmt->close();
        log_status_change($orderId, 'rider_assigned', $admin['username']);
        flash('রাইডার অ্যাসাইন হয়েছে।');
    }
    redirect('admin/orders.php' . (!empty($_POST['back']) ? '?' . $_POST['back'] : ''));
}

$status = $_GET['status'] ?? '';
$q      = trim($_GET['q'] ?? '');
$where  = ['1=1']; $params = []; $types = '';

if ($status && array_key_exists($status, order_statuses())) { $where[] = 'o.order_status = ?'; $params[] = $status; $types .= 's'; }
if ($q !== '') {
    $where[] = '(o.order_code LIKE ? OR o.guest_phone LIKE ? OR o.guest_name LIKE ? OR o.trx_id LIKE ?)';
    $like = "%$q%";
    array_push($params, $like, $like, $like, $like); $types .= 'ssss';
}
$whereSql = implode(' AND ', $where);

$stmt = $conn->prepare("SELECT o.*, r.name rider_name FROM orders o
                        LEFT JOIN riders r ON r.id = o.rider_id
                        WHERE $whereSql ORDER BY o.id DESC LIMIT 100");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$orders = $stmt->get_result();
$stmt->close();

$riders = $conn->query("SELECT id, name, phone FROM riders WHERE status='active' ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$backQs = http_build_query($_GET);
?>

<h1 class="h4 fw-bold mb-3">অর্ডার ম্যানেজমেন্ট</h1>

<form class="panel panel-body mb-3" method="get">
  <div class="row g-2 align-items-end">
    <div class="col-md-5">
      <label class="form-label" for="q">খুঁজুন</label>
      <input class="form-control" id="q" name="q" value="<?= h($q) ?>" placeholder="অর্ডার কোড, ফোন, নাম বা TRX ID">
    </div>
    <div class="col-md-4">
      <label class="form-label" for="status">স্ট্যাটাস</label>
      <select class="form-select" id="status" name="status">
        <option value="">সব</option>
        <?php foreach (order_statuses() as $k => $v): ?>
          <option value="<?= $k ?>" <?= $status === $k ? 'selected' : '' ?>><?= $v ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3 d-flex gap-2">
      <button class="btn btn-green flex-grow-1">ফিল্টার</button>
      <a class="btn btn-outline-green" href="<?= admin_url('orders.php') ?>">রিসেট</a>
    </div>
  </div>
</form>

<div class="panel">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>অর্ডার</th><th>কাস্টমার</th><th>মোট</th><th>পেমেন্ট</th>
          <th>রাইডার</th><th>স্ট্যাটাস</th><th></th>
        </tr>
      </thead>
      <tbody>
      <?php while ($o = $orders->fetch_assoc()): ?>
        <tr class="<?= $o['order_status'] === 'pending' ? 'is-new' : '' ?>">
          <td>
            <a class="fw-semibold text-reset" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>"><?= h($o['order_code']) ?></a>
            <div class="text-muted small"><?= date('d M, h:i A', strtotime($o['created_at'])) ?></div>
          </td>
          <td>
            <div><?= h($o['guest_name']) ?></div>
            <a class="text-muted small" href="tel:<?= h($o['guest_phone']) ?>"><?= h($o['guest_phone']) ?></a>
          </td>
          <td><?= taka($o['total']) ?></td>
          <td>
            <?php if ($o['advance_paid_status'] === 'not_required'): ?>
              <span class="text-muted small">ক্যাশ অন ডেলিভারি</span>
            <?php else: ?>
              <span class="badge bg-<?= ['pending'=>'warning text-dark','approved'=>'success','rejected'=>'danger'][$o['advance_paid_status']] ?? 'secondary' ?>">
                <?= h(payment_status_label($o['advance_paid_status'])) ?>
              </span>
            <?php endif; ?>
          </td>
          <td>
            <form method="post" class="d-flex gap-1">
              <?= csrf_field() ?>
              <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
              <input type="hidden" name="back" value="<?= h($backQs) ?>">
              <select class="form-select form-select-sm" name="rider_id" style="min-width:130px">
                <option value="0">— রাইডার নেই —</option>
                <?php foreach ($riders as $r): ?>
                  <option value="<?= (int)$r['id'] ?>" <?= (int)$o['rider_id'] === (int)$r['id'] ? 'selected' : '' ?>><?= h($r['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-sm btn-outline-green" name="assign_rider" value="1" title="অ্যাসাইন করুন">
                <i class="bi bi-check2"></i>
              </button>
            </form>
          </td>
          <td>
            <form method="post" class="d-flex gap-1">
              <?= csrf_field() ?>
              <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
              <input type="hidden" name="back" value="<?= h($backQs) ?>">
              <select class="form-select form-select-sm" name="status" style="min-width:140px">
                <?php foreach (order_statuses() as $k => $v): ?>
                  <option value="<?= $k ?>" <?= $o['order_status'] === $k ? 'selected' : '' ?>><?= $v ?></option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-sm btn-green" name="set_status" value="1" title="সেভ করুন"><i class="bi bi-save"></i></button>
            </form>
          </td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-green" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>">বিস্তারিত</a>
            <a class="btn btn-sm btn-outline-green" href="<?= admin_url('invoice.php?id=' . (int)$o['id'] . '&print=1') ?>"
               target="_blank" title="ইনভয়েস প্রিন্ট"><i class="bi bi-printer"></i></a>
          </td>
        </tr>
      <?php endwhile; ?>
      <?php if (!$orders->num_rows): ?>
        <tr><td colspan="7" class="text-center text-muted py-4">এই ফিল্টারে কোনো অর্ডার নেই।</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
