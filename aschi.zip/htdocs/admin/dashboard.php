<?php
$__title = 'ড্যাশবোর্ড';
require_once __DIR__ . '/includes/admin_header.php';

$one = function ($sql) use ($conn) { return $conn->query($sql)->fetch_assoc(); };

$totalOrders   = (int)$one("SELECT COUNT(*) c FROM orders")['c'];
$pending       = (int)$one("SELECT COUNT(*) c FROM orders WHERE order_status='pending'")['c'];
$todayRevenue  = (float)$one("SELECT COALESCE(SUM(total),0) s FROM orders
                              WHERE DATE(created_at)=CURDATE() AND order_status<>'cancelled'")['s'];
$payPending    = (int)$one("SELECT COUNT(*) c FROM orders WHERE advance_paid_status='pending'")['c'];
$delivered     = (int)$one("SELECT COUNT(*) c FROM orders WHERE order_status='delivered'")['c'];
$customers     = (int)$one("SELECT COUNT(*) c FROM users")['c'];
$lowStock      = $conn->query("SELECT id, name, stock, unit FROM products WHERE status='active' AND stock <= 5 ORDER BY stock ASC LIMIT 6");
$recent        = $conn->query("SELECT * FROM orders ORDER BY id DESC LIMIT 8");

$cards = [
  ['মোট অর্ডার', bn_num($totalOrders), 'receipt'],
  ['পেন্ডিং অর্ডার', bn_num($pending), 'hourglass-split'],
  ['আজকের রেভিনিউ', taka($todayRevenue), 'graph-up-arrow'],
  ['অ্যাপ্রুভাল পেন্ডিং পেমেন্ট', bn_num($payPending), 'cash-coin'],
  ['ডেলিভারি সম্পন্ন', bn_num($delivered), 'check2-circle'],
  ['রেজিস্টার্ড কাস্টমার', bn_num($customers), 'people'],
];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h4 fw-bold mb-0">ড্যাশবোর্ড</h1>
  <span class="badge <?= ordering_open() ? 'bg-success' : 'bg-danger' ?>">
    অর্ডার <?= ordering_open() ? 'চালু' : 'বন্ধ' ?>
  </span>
</div>

<div class="row row-cols-2 row-cols-lg-3 g-3 mb-4">
  <?php foreach ($cards as [$label, $value, $icon]): ?>
    <div class="col">
      <div class="stat-card">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="label"><?= $label ?></div>
            <div class="value"><?= $value ?></div>
          </div>
          <i class="bi bi-<?= $icon ?> icon"></i>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="panel">
      <div class="panel-head">
        <h2 class="h6 fw-bold mb-0">সাম্প্রতিক অর্ডার</h2>
        <a href="<?= admin_url('orders.php') ?>" class="btn btn-sm btn-outline-green">সব অর্ডার</a>
      </div>
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light">
            <tr><th>অর্ডার</th><th>কাস্টমার</th><th>মোট</th><th>স্ট্যাটাস</th><th></th></tr>
          </thead>
          <tbody>
          <?php while ($o = $recent->fetch_assoc()): ?>
            <tr class="<?= $o['order_status'] === 'pending' ? 'is-new' : '' ?>">
              <td>
                <div class="fw-semibold"><?= h($o['order_code']) ?></div>
                <div class="text-muted small"><?= date('d M, h:i A', strtotime($o['created_at'])) ?></div>
              </td>
              <td>
                <div><?= h($o['guest_name']) ?></div>
                <div class="text-muted small"><?= h($o['guest_phone']) ?></div>
              </td>
              <td><?= taka($o['total']) ?></td>
              <td><span class="badge bg-<?= status_color($o['order_status']) ?>"><?= h(status_label($o['order_status'])) ?></span></td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-green" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>">দেখুন</a>
              </td>
            </tr>
          <?php endwhile; ?>
          <?php if (!$recent->num_rows): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">এখনো কোনো অর্ডার আসেনি।</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">স্টক কমে আসছে</h2></div>
      <div class="panel-body">
        <?php if (!$lowStock->num_rows): ?>
          <p class="text-muted mb-0">সব পণ্যের স্টক ঠিক আছে।</p>
        <?php else: ?>
          <?php while ($p = $lowStock->fetch_assoc()): ?>
            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
              <a href="<?= admin_url('products.php?edit=' . (int)$p['id']) ?>" class="text-reset"><?= h($p['name']) ?></a>
              <span class="badge <?= $p['stock'] == 0 ? 'bg-danger' : 'bg-warning text-dark' ?>">
                <?= bn_num($p['stock']) ?> <?= h($p['unit']) ?>
              </span>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
