<?php
$__title = 'অ্যাডমিন ও ম্যানেজার';
require_once __DIR__ . '/includes/auth.php';
require_admin();
require_role_admin();
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (isset($_POST['add'])) {
        $name     = trim($_POST['name']);
        $username = trim($_POST['username']);
        $password = $_POST['password'] ?? '';
        $role     = $_POST['role'] === 'admin' ? 'admin' : 'manager';

        if ($username === '' || strlen($password) < 6) {
            flash('ইউজারনেম দিন এবং কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।', 'error');
            redirect('admin/admins.php');
        }
        $stmt = $conn->prepare("SELECT id FROM admins WHERE username=?");
        $stmt->bind_param('s', $username); $stmt->execute();
        $exists = $stmt->get_result()->num_rows; $stmt->close();
        if ($exists) { flash('এই ইউজারনেম আগেই আছে।', 'error'); redirect('admin/admins.php'); }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO admins (name, username, password, role) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $name, $username, $hash, $role);
        $stmt->execute(); $stmt->close();
        flash('নতুন ব্যবহারকারী যোগ হয়েছে।');
        redirect('admin/admins.php');
    }

    if (isset($_POST['reset_password'])) {
        $id = (int)$_POST['id'];
        $password = $_POST['new_password'] ?? '';
        if (strlen($password) < 6) { flash('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।', 'error'); redirect('admin/admins.php'); }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE admins SET password=? WHERE id=?");
        $stmt->bind_param('si', $hash, $id); $stmt->execute(); $stmt->close();
        flash('পাসওয়ার্ড বদলানো হয়েছে।');
        redirect('admin/admins.php');
    }

    if (isset($_POST['toggle'])) {
        $id = (int)$_POST['toggle'];
        if ($id === (int)$admin['id']) { flash('নিজের অ্যাকাউন্ট বন্ধ করা যাবে না।', 'error'); redirect('admin/admins.php'); }
        $stmt = $conn->prepare("UPDATE admins SET status = IF(status='active','inactive','active') WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        redirect('admin/admins.php');
    }
}

$rows = $conn->query("SELECT * FROM admins ORDER BY id");
?>
<h1 class="h4 fw-bold mb-3">অ্যাডমিন ও ম্যানেজার</h1>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-head"><h2 class="h6 fw-bold mb-0">নতুন ব্যবহারকারী</h2></div>
      <div class="panel-body">
        <form method="post">
          <?= csrf_field() ?>
          <div class="mb-2">
            <label class="form-label" for="name">নাম</label>
            <input class="form-control" id="name" name="name">
          </div>
          <div class="mb-2">
            <label class="form-label" for="username">ইউজারনেম</label>
            <input class="form-control" id="username" name="username" required>
          </div>
          <div class="mb-2">
            <label class="form-label" for="password">পাসওয়ার্ড</label>
            <input class="form-control" id="password" name="password" type="password" required>
          </div>
          <div class="mb-3">
            <label class="form-label" for="role">রোল</label>
            <select class="form-select" id="role" name="role">
              <option value="manager">ম্যানেজার — অর্ডার ও পণ্য</option>
              <option value="admin">অ্যাডমিন — সব কিছু</option>
            </select>
          </div>
          <button class="btn btn-green w-100" name="add" value="1">যোগ করুন</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="panel">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light"><tr><th>ব্যবহারকারী</th><th>রোল</th><th>অবস্থা</th><th>পাসওয়ার্ড রিসেট</th></tr></thead>
          <tbody>
          <?php while ($a = $rows->fetch_assoc()): ?>
            <tr>
              <td>
                <div class="fw-semibold"><?= h($a['name'] ?: $a['username']) ?></div>
                <div class="text-muted small"><?= h($a['username']) ?></div>
              </td>
              <td><span class="badge <?= $a['role']==='admin'?'bg-success':'bg-secondary' ?>"><?= $a['role']==='admin'?'অ্যাডমিন':'ম্যানেজার' ?></span></td>
              <td>
                <form method="post" class="d-inline"><?= csrf_field() ?>
                  <button class="btn btn-sm <?= $a['status']==='active'?'btn-green':'btn-outline-danger' ?>" name="toggle" value="<?= (int)$a['id'] ?>">
                    <?= $a['status']==='active'?'সক্রিয়':'নিষ্ক্রিয়' ?>
                  </button>
                </form>
              </td>
              <td>
                <form method="post" class="d-flex gap-1"><?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                  <input class="form-control form-control-sm" name="new_password" type="password" placeholder="নতুন পাসওয়ার্ড" style="max-width:170px">
                  <button class="btn btn-sm btn-outline-green" name="reset_password" value="1">সেট</button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
