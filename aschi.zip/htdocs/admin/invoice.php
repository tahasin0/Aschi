<?php
/**
 * Printable delivery slip / invoice.
 * Opens in a new tab from the order pages and triggers the print dialog.
 */
require_once __DIR__ . '/includes/auth.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT o.*, r.name rider_name, r.phone rider_phone
                        FROM orders o LEFT JOIN riders r ON r.id = o.rider_id
                        WHERE o.id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$o = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$o) { flash('অর্ডার পাওয়া যায়নি।', 'error'); redirect('admin/orders.php'); }

$stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$advancePaid = $o['advance_paid_status'] === 'approved';
$collect     = $advancePaid ? (float)$o['subtotal'] : (float)$o['total'];
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ইনভয়েস <?= h($o['order_code']) ?> — Aschi</title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  :root { --green:#16A34A; --line:#DDE3DF; --muted:#6B7B71; }
  * { box-sizing: border-box; }
  body { font-family:'Hind Siliguri',sans-serif; margin:0; padding:24px; color:#14231A; background:#F5F7F6; }
  .sheet { max-width:760px; margin:0 auto; background:#fff; padding:28px; border:1px solid var(--line); border-radius:12px; }
  .top { display:flex; justify-content:space-between; align-items:flex-start; gap:16px;
         border-bottom:2px solid var(--green); padding-bottom:14px; margin-bottom:18px; }
  .top img { height:62px; }
  .code { font-size:20px; font-weight:700; color:var(--green); }
  .muted { color:var(--muted); font-size:13px; }
  .grid { display:flex; gap:24px; flex-wrap:wrap; margin-bottom:18px; }
  .grid > div { flex:1; min-width:200px; }
  h2 { font-size:14px; margin:0 0 6px; }
  table { width:100%; border-collapse:collapse; margin-top:6px; }
  th, td { padding:9px 8px; border-bottom:1px solid var(--line); text-align:left; font-size:14px; }
  th { background:#F0FBF4; font-size:13px; }
  td.num, th.num { text-align:right; }
  tfoot td { border-bottom:0; padding:5px 8px; }
  tfoot tr.total td { font-size:17px; font-weight:700; border-top:2px solid var(--green); padding-top:9px; }
  .collect { margin-top:16px; padding:12px 14px; border:2px dashed var(--green);
             border-radius:10px; display:flex; justify-content:space-between; align-items:center; }
  .collect .amount { font-size:22px; font-weight:700; color:var(--green); }
  .note { margin-top:14px; padding:10px 12px; background:#FFF4E5; border-radius:8px; font-size:14px; }
  .sign { display:flex; gap:40px; margin-top:44px; }
  .sign div { flex:1; border-top:1px solid var(--line); padding-top:6px; font-size:13px; color:var(--muted); text-align:center; }
  .actions { max-width:760px; margin:0 auto 14px; display:flex; gap:8px; }
  .btn { font-family:inherit; font-size:14px; padding:8px 18px; border-radius:8px; cursor:pointer;
         border:1px solid var(--green); background:var(--green); color:#fff; text-decoration:none; }
  .btn.ghost { background:#fff; color:var(--green); }
  @media print {
    body { background:#fff; padding:0; }
    .actions { display:none; }
    .sheet { border:0; border-radius:0; max-width:none; padding:0; }
  }
</style>
</head>
<body>

<div class="actions">
  <button class="btn" onclick="window.print()">প্রিন্ট করুন</button>
  <a class="btn ghost" href="<?= admin_url('order-view.php?id=' . (int)$o['id']) ?>">← অর্ডারে ফিরে যান</a>
</div>

<div class="sheet">
  <div class="top">
    <div>
      <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi">
      <div class="muted"><?= h(setting('contact_address')) ?><br><?= h(setting('support_phone')) ?></div>
    </div>
    <div style="text-align:right">
      <div class="code"><?= h($o['order_code']) ?></div>
      <div class="muted"><?= date('d M Y, h:i A', strtotime($o['created_at'])) ?></div>
      <div class="muted">স্ট্যাটাস: <?= h(status_label($o['order_status'])) ?></div>
    </div>
  </div>

  <div class="grid">
    <div>
      <h2>কাস্টমার</h2>
      <div><?= h($o['guest_name']) ?></div>
      <div><?= h($o['guest_phone']) ?></div>
      <div class="muted"><?= nl2br(h($o['guest_address'])) ?></div>
    </div>
    <div>
      <h2>ডেলিভারি</h2>
      <div><?= $o['rider_name'] ? h($o['rider_name']) . ' — ' . h($o['rider_phone']) : 'রাইডার নিযুক্ত হয়নি' ?></div>
      <div class="muted">পেমেন্ট: <?= $advancePaid ? 'অগ্রিম চার্জ পরিশোধিত (TRX ' . h($o['trx_id']) . ')' : 'ক্যাশ অন ডেলিভারি' ?></div>
    </div>
  </div>

  <table>
    <thead>
      <tr><th style="width:36px" class="num">#</th><th>পণ্য</th><th class="num">পরিমাণ</th><th class="num">দাম</th><th class="num">মোট</th></tr>
    </thead>
    <tbody>
      <?php foreach ($items as $i => $it): ?>
      <tr>
        <td class="num"><?= bn_num($i + 1) ?></td>
        <td><?= h($it['product_name']) ?></td>
        <td class="num"><?= bn_num($it['quantity']) ?> <?= h($it['unit']) ?></td>
        <td class="num"><?= taka($it['price']) ?></td>
        <td class="num"><?= taka($it['quantity'] * $it['price']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr><td colspan="4" class="num muted">সাবটোটাল</td><td class="num"><?= taka($o['subtotal']) ?></td></tr>
      <tr><td colspan="4" class="num muted">ডেলিভারি চার্জ<?= $advancePaid ? ' (অগ্রিম পরিশোধিত)' : '' ?></td><td class="num"><?= taka($o['delivery_charge']) ?></td></tr>
      <tr class="total"><td colspan="4" class="num">সর্বমোট</td><td class="num"><?= taka($o['total']) ?></td></tr>
    </tfoot>
  </table>

  <div class="collect">
    <span>রাইডার যত টাকা নেবে</span>
    <span class="amount"><?= taka($collect) ?></span>
  </div>

  <?php if ($o['note']): ?>
    <div class="note"><strong>কাস্টমারের নির্দেশনা:</strong> <?= nl2br(h($o['note'])) ?></div>
  <?php endif; ?>

  <div class="sign">
    <div>রাইডারের স্বাক্ষর</div>
    <div>কাস্টমারের স্বাক্ষর</div>
  </div>
</div>

<script>
  // Auto-open the print dialog when opened with ?print=1
  <?php if (!empty($_GET['print'])): ?>window.addEventListener('load', function(){ window.print(); });<?php endif; ?>
</script>
</body>
</html>
