<?php
$__title = 'পণ্য ম্যানেজমেন্ট';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if (isset($_POST['save'])) {
        $id          = (int)($_POST['id'] ?? 0);
        $category_id = (int)$_POST['category_id'] ?: null;
        $name        = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price       = (float)$_POST['price'];
        $old_price   = $_POST['old_price'] !== '' ? (float)$_POST['old_price'] : null;
        $unit        = trim($_POST['unit']) ?: 'কেজি';
        $stock       = (int)$_POST['stock'];
        $featured    = isset($_POST['is_featured']) ? 1 : 0;
        $status      = $_POST['status'] === 'inactive' ? 'inactive' : 'active';

        if ($name === '' || $price <= 0) {
            flash('পণ্যের নাম ও সঠিক দাম দিতে হবে।', 'error');
            redirect('admin/products.php');
        }

        $image = upload_image('image', 'products');

        if ($id) {
            if ($image) {
                $stmt = $conn->prepare("SELECT image FROM products WHERE id=?");
                $stmt->bind_param('i', $id); $stmt->execute();
                $old = $stmt->get_result()->fetch_assoc(); $stmt->close();
                if ($old && $old['image']) delete_image($old['image'], 'products');

                $stmt = $conn->prepare("UPDATE products SET category_id=?, name=?, description=?, price=?, old_price=?,
                                        unit=?, stock=?, is_featured=?, status=?, image=? WHERE id=?");
                $stmt->bind_param('issddsiissi', $category_id, $name, $description, $price, $old_price,
                                   $unit, $stock, $featured, $status, $image, $id);
            } else {
                $stmt = $conn->prepare("UPDATE products SET category_id=?, name=?, description=?, price=?, old_price=?,
                                        unit=?, stock=?, is_featured=?, status=? WHERE id=?");
                $stmt->bind_param('issddsiisi', $category_id, $name, $description, $price, $old_price,
                                   $unit, $stock, $featured, $status, $id);
            }
            $stmt->execute(); $stmt->close();
            flash('পণ্য আপডেট হয়েছে।');
        } else {
            $stmt = $conn->prepare("INSERT INTO products (category_id, name, description, price, old_price, unit, stock, is_featured, status, image)
                                    VALUES (?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param('issddsiiss', $category_id, $name, $description, $price, $old_price,
                               $unit, $stock, $featured, $status, $image);
            $stmt->execute();
            $id = $conn->insert_id;
            $stmt->close();
            flash('নতুন পণ্য যোগ হয়েছে।');
        }

        // Extra gallery images (max 6 per product)
        $existing = 0;
        $chk = $conn->prepare("SELECT COUNT(*) c FROM product_images WHERE product_id=?");
        $chk->bind_param('i', $id); $chk->execute();
        $existing = (int)$chk->get_result()->fetch_assoc()['c']; $chk->close();

        $gallery = upload_images('gallery', 'products', max(0, 6 - $existing));
        if ($gallery) {
            $gs = $conn->prepare("INSERT INTO product_images (product_id, image) VALUES (?,?)");
            foreach ($gallery as $g) { $gs->bind_param('is', $id, $g); $gs->execute(); }
            $gs->close();
        }

        redirect('admin/products.php' . ($gallery || $existing ? '?edit=' . $id : ''));
    }

    if (isset($_POST['delete_gallery'])) {
        $imgId = (int)$_POST['delete_gallery'];
        $pid   = (int)$_POST['product_id'];
        $stmt = $conn->prepare("SELECT image FROM product_images WHERE id=?");
        $stmt->bind_param('i', $imgId); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($row) delete_image($row['image'], 'products');

        $stmt = $conn->prepare("DELETE FROM product_images WHERE id=?");
        $stmt->bind_param('i', $imgId); $stmt->execute(); $stmt->close();
        flash('ছবিটি মুছে ফেলা হয়েছে।');
        redirect('admin/products.php?edit=' . $pid);
    }

    if (isset($_POST['delete'])) {
        require_role_admin();
        $id = (int)$_POST['delete'];
        $stmt = $conn->prepare("SELECT image FROM products WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($row) delete_image($row['image'], 'products');

        $stmt = $conn->prepare("SELECT image FROM product_images WHERE product_id=?");
        $stmt->bind_param('i', $id); $stmt->execute();
        foreach ($stmt->get_result()->fetch_all(MYSQLI_ASSOC) as $g) delete_image($g['image'], 'products');
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM products WHERE id=?");
        $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
        flash('পণ্য মুছে ফেলা হয়েছে।');
        redirect('admin/products.php');
    }

    if (isset($_POST['quick_stock'])) {
        $id = (int)$_POST['id']; $stock = (int)$_POST['stock']; $price = (float)$_POST['price'];
        $stmt = $conn->prepare("UPDATE products SET stock=?, price=? WHERE id=?");
        $stmt->bind_param('idi', $stock, $price, $id);
        $stmt->execute(); $stmt->close();
        flash('স্টক ও দাম আপডেট হয়েছে।');
        redirect('admin/products.php');
    }
}

$edit = null;
$editGallery = [];
if (!empty($_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
    $stmt->bind_param('i', $_GET['edit']); $stmt->execute();
    $edit = $stmt->get_result()->fetch_assoc(); $stmt->close();

    if ($edit) {
        $stmt = $conn->prepare("SELECT * FROM product_images WHERE product_id=? ORDER BY id");
        $stmt->bind_param('i', $edit['id']); $stmt->execute();
        $editGallery = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    }
}

$cats = $conn->query("SELECT id, name FROM categories ORDER BY sort_order, id")->fetch_all(MYSQLI_ASSOC);
$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $stmt = $conn->prepare("SELECT p.*, c.name cat_name FROM products p LEFT JOIN categories c ON c.id=p.category_id
                            WHERE p.name LIKE ? ORDER BY p.id DESC");
    $like = "%$q%"; $stmt->bind_param('s', $like); $stmt->execute();
    $rows = $stmt->get_result(); $stmt->close();
} else {
    $rows = $conn->query("SELECT p.*, c.name cat_name FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC");
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h4 fw-bold mb-0">পণ্য ম্যানেজমেন্ট</h1>
  <form class="d-flex gap-2" method="get">
    <input class="form-control form-control-sm" name="q" value="<?= h($q) ?>" placeholder="পণ্য খুঁজুন">
    <button class="btn btn-sm btn-outline-green">খুঁজুন</button>
  </form>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="panel">
      <div class="panel-head">
        <h2 class="h6 fw-bold mb-0"><?= $edit ? 'পণ্য এডিট' : 'নতুন পণ্য যোগ করুন' ?></h2>
        <?php if ($edit): ?><a class="btn btn-sm btn-outline-green" href="<?= admin_url('products.php') ?>">নতুন</a><?php endif; ?>
      </div>
      <div class="panel-body">
        <form method="post" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">

          <div class="mb-2">
            <label class="form-label" for="name">পণ্যের নাম</label>
            <input class="form-control" id="name" name="name" value="<?= h($edit['name'] ?? '') ?>" required>
          </div>
          <div class="mb-2">
            <label class="form-label" for="category_id">ক্যাটেগরি</label>
            <select class="form-select" id="category_id" name="category_id">
              <option value="0">— নেই —</option>
              <?php foreach ($cats as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= (int)($edit['category_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="row g-2 mb-2">
            <div class="col-6">
              <label class="form-label" for="price">দাম</label>
              <input class="form-control" id="price" name="price" type="number" step="0.01" value="<?= h($edit['price'] ?? '') ?>" required>
            </div>
            <div class="col-6">
              <label class="form-label" for="old_price">আগের দাম</label>
              <input class="form-control" id="old_price" name="old_price" type="number" step="0.01" value="<?= h($edit['old_price'] ?? '') ?>">
            </div>
          </div>
          <div class="row g-2 mb-2">
            <div class="col-6">
              <label class="form-label" for="unit">ইউনিট</label>
              <input class="form-control" id="unit" name="unit" value="<?= h($edit['unit'] ?? 'কেজি') ?>" placeholder="কেজি / পিস / লিটার">
            </div>
            <div class="col-6">
              <label class="form-label" for="stock">স্টক</label>
              <input class="form-control" id="stock" name="stock" type="number" value="<?= h($edit['stock'] ?? 0) ?>">
            </div>
          </div>
          <div class="mb-2">
            <label class="form-label" for="description">বর্ণনা</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?= h($edit['description'] ?? '') ?></textarea>
          </div>
          <div class="mb-2">
            <label class="form-label" for="image">প্রধান ছবি</label>
            <input class="form-control" id="image" name="image" type="file" accept="image/*">
            <?php if (!empty($edit['image'])): ?>
              <img src="<?= product_image($edit['image']) ?>" alt="" class="rounded-3 mt-2" width="72" height="72" style="object-fit:cover">
            <?php endif; ?>
          </div>

          <div class="mb-2">
            <label class="form-label" for="gallery">অতিরিক্ত ছবি (সর্বোচ্চ ৬টি)</label>
            <input class="form-control" id="gallery" name="gallery[]" type="file" accept="image/*" multiple>
            <div class="form-text">একসাথে কয়েকটি ছবি বেছে নিতে পারেন। ডিটেইল পেজে থাম্বনেইল হিসেবে দেখাবে।</div>
          </div>
          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured" <?= !empty($edit['is_featured']) ? 'checked' : '' ?>>
            <label class="form-check-label" for="is_featured">হোমপেজে ফিচার করুন</label>
          </div>
          <div class="mb-3">
            <label class="form-label" for="status">স্ট্যাটাস</label>
            <select class="form-select" id="status" name="status">
              <option value="active" <?= ($edit['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>সক্রিয়</option>
              <option value="inactive" <?= ($edit['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>নিষ্ক্রিয়</option>
            </select>
          </div>
          <button class="btn btn-green w-100" name="save" value="1"><?= $edit ? 'আপডেট করুন' : 'পণ্য যোগ করুন' ?></button>
        </form>

        <?php if ($editGallery): ?>
          <hr>
          <label class="form-label">বর্তমান অতিরিক্ত ছবি</label>
          <div class="d-flex flex-wrap gap-2">
            <?php foreach ($editGallery as $g): ?>
              <div class="position-relative">
                <img src="<?= product_image($g['image']) ?>" alt="" width="68" height="68" class="rounded-3" style="object-fit:cover">
                <form method="post" class="position-absolute top-0 end-0" data-confirm="ছবিটি মুছে ফেলবেন?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="product_id" value="<?= (int)$edit['id'] ?>">
                  <button class="btn btn-sm btn-danger py-0 px-1" name="delete_gallery" value="<?= (int)$g['id'] ?>"
                          style="line-height:1.1" aria-label="ছবি মুছুন">&times;</button>
                </form>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="panel">
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light"><tr><th>পণ্য</th><th>ক্যাটেগরি</th><th style="width:170px">দাম ও স্টক</th><th>অবস্থা</th><th></th></tr></thead>
          <tbody>
          <?php while ($p = $rows->fetch_assoc()): ?>
            <tr>
              <td>
                <div class="d-flex gap-2 align-items-center">
                  <img src="<?= product_image($p['image']) ?>" alt="" width="44" height="44" class="rounded-3" style="object-fit:cover">
                  <div>
                    <div class="fw-semibold"><?= h($p['name']) ?></div>
                    <div class="text-muted small"><?= h($p['unit']) ?><?= $p['is_featured'] ? ' · ফিচার্ড' : '' ?></div>
                  </div>
                </div>
              </td>
              <td class="small"><?= h($p['cat_name'] ?? '—') ?></td>
              <td>
                <form method="post" class="d-flex gap-1">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                  <input class="form-control form-control-sm" name="price" type="number" step="0.01" value="<?= h($p['price']) ?>" style="width:78px">
                  <input class="form-control form-control-sm" name="stock" type="number" value="<?= (int)$p['stock'] ?>" style="width:64px">
                  <button class="btn btn-sm btn-green" name="quick_stock" value="1" title="সেভ"><i class="bi bi-save"></i></button>
                </form>
              </td>
              <td>
                <span class="badge <?= $p['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?>"><?= $p['status'] === 'active' ? 'সক্রিয়' : 'নিষ্ক্রিয়' ?></span>
              </td>
              <td class="text-end">
                <a class="btn btn-sm btn-outline-green" href="<?= admin_url('products.php?edit=' . (int)$p['id']) ?>"><i class="bi bi-pencil"></i></a>
                <?php if ($admin['role'] === 'admin'): ?>
                <form method="post" class="d-inline" data-confirm="পণ্যটি মুছে ফেলবেন?">
                  <?= csrf_field() ?>
                  <button class="btn btn-sm btn-outline-danger" name="delete" value="<?= (int)$p['id'] ?>"><i class="bi bi-trash"></i></button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
