-- =====================================================
-- Aschi — Online Grocery / Food Delivery Platform
-- Database schema (MySQL 5.7+ / MariaDB 10.3+)
-- Run this file FIRST, before using the application.
-- =====================================================

CREATE DATABASE IF NOT EXISTS aschi_db
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE aschi_db;

-- ---------- Customers ----------
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(100) DEFAULT NULL,
  password VARCHAR(255) NOT NULL,
  address TEXT,
  status ENUM('active','blocked') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Categories ----------
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(120) UNIQUE,
  icon_image VARCHAR(255) DEFAULT NULL,
  sort_order INT DEFAULT 0,
  status ENUM('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Products ----------
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  old_price DECIMAL(10,2) DEFAULT NULL,
  unit VARCHAR(20) DEFAULT 'কেজি',
  image VARCHAR(255) DEFAULT NULL,
  stock INT DEFAULT 0,
  is_featured TINYINT(1) DEFAULT 0,
  sold_count INT DEFAULT 0,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Extra product images (gallery) ----------
CREATE TABLE IF NOT EXISTS product_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT,
  image VARCHAR(255),
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Riders ----------
CREATE TABLE IF NOT EXISTS riders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  photo VARCHAR(255) DEFAULT NULL,
  social_link VARCHAR(255) DEFAULT NULL,
  api_token VARCHAR(64) DEFAULT NULL,
  current_lat DECIMAL(10,7) DEFAULT NULL,
  current_lng DECIMAL(10,7) DEFAULT NULL,
  location_updated_at DATETIME DEFAULT NULL,
  status ENUM('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Orders ----------
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_code VARCHAR(30) UNIQUE NOT NULL,
  user_id INT NULL,
  guest_name VARCHAR(100),
  guest_phone VARCHAR(20),
  guest_address TEXT,
  note TEXT,
  rider_id INT NULL,
  subtotal DECIMAL(10,2) DEFAULT 0,
  delivery_charge DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) DEFAULT 0,
  advance_required TINYINT(1) DEFAULT 0,
  advance_paid_status ENUM('not_required','pending','approved','rejected') DEFAULT 'not_required',
  trx_id VARCHAR(50) NULL,
  payment_number_used VARCHAR(20) NULL,
  payment_method VARCHAR(30) NULL,
  order_status ENUM('pending','confirmed','rider_assigned','picked_up','on_the_way','delivered','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (rider_id) REFERENCES riders(id) ON DELETE SET NULL,
  UNIQUE KEY uniq_trx (trx_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Order items ----------
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  product_id INT NULL,
  product_name VARCHAR(150),
  unit VARCHAR(20),
  quantity INT,
  price DECIMAL(10,2),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Order status history (timeline) ----------
CREATE TABLE IF NOT EXISTS order_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  status VARCHAR(30),
  changed_by VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Homepage slider banners ----------
CREATE TABLE IF NOT EXISTS banners (
  id INT AUTO_INCREMENT PRIMARY KEY,
  image VARCHAR(255),
  link VARCHAR(255) DEFAULT NULL,
  sort_order INT DEFAULT 0,
  status ENUM('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Site settings (key/value admin toggles) ----------
CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE,
  setting_value TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Admins / managers ----------
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  username VARCHAR(50) UNIQUE,
  password VARCHAR(255),
  role ENUM('admin','manager') DEFAULT 'manager',
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Login attempt log (brute force protection) ----------
CREATE TABLE IF NOT EXISTS login_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45),
  username VARCHAR(100),
  attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ip_time (ip, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Seed data
-- =====================================================

INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
('site_name', 'Aschi'),
('order_status_global', 'on'),
('order_off_message', 'এই মুহূর্তে অর্ডার নেওয়া বন্ধ আছে। একটু পরে আবার চেষ্টা করুন।'),
('advance_charge_enabled', '0'),
('advance_charge_amount', '60'),
('delivery_charge', '60'),
('free_delivery_above', '1000'),
('payment_number', '01XXXXXXXXX'),
('payment_method_name', 'বিকাশ (পার্সোনাল)'),
('support_link', 'https://wa.me/8801XXXXXXXXX'),
('support_phone', '01XXXXXXXXX'),
('banner_text', 'আজকের তাজা সবজি ও মাছ — সকাল ৮টা থেকে রাত ১০টা পর্যন্ত ডেলিভারি চলছে। ৳১০০০ টাকার উপরে অর্ডারে ডেলিভারি ফ্রি।'),
('banner_speed', '35'),
('banner_direction', 'left'),
('google_maps_key', ''),
('loader_enabled', '1'),
('contact_address', 'চট্টগ্রাম, বাংলাদেশ');

-- No admin account is created here on purpose — a hard-coded password would be
-- a standing security hole. After importing this file, open install.php in the
-- browser once to create the first admin account, then delete install.php.

INSERT IGNORE INTO categories (id, name, slug, sort_order) VALUES
(1, 'কাঁচাবাজার', 'kacha-bazar', 1),
(2, 'সবজি', 'sobji', 2),
(3, 'মাছ', 'mach', 3),
(4, 'মাংস', 'mangsho', 4),
(5, 'ডেইলি নিডস', 'daily-needs', 5);

INSERT IGNORE INTO products (id, category_id, name, description, price, old_price, unit, stock, is_featured) VALUES
(1, 2, 'দেশি আলু', 'তাজা দেশি আলু, বাছাই করা।', 45.00, 55.00, 'কেজি', 200, 1),
(2, 2, 'পেঁয়াজ (দেশি)', 'ভালো মানের দেশি পেঁয়াজ।', 95.00, NULL, 'কেজি', 150, 1),
(3, 3, 'রুই মাছ (কাটা)', 'তাজা রুই মাছ, কেটে পরিষ্কার করে দেওয়া হয়।', 380.00, 420.00, 'কেজি', 40, 1),
(4, 4, 'দেশি মুরগি', 'ফার্ম নয় — আসল দেশি মুরগি।', 620.00, NULL, 'কেজি', 25, 1),
(5, 2, 'টমেটো', 'রসালো তাজা টমেটো।', 70.00, NULL, 'কেজি', 90, 0),
(6, 5, 'সয়াবিন তেল', '১ লিটার বোতল।', 175.00, NULL, 'লিটার', 120, 1);
