<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $newPass = $_POST['password'] ?? '';

    if ($name === '') {
        flash('নাম খালি রাখা যাবে না।', 'error');
    } else {
        $stmt = $conn->prepare("UPDATE users SET name=?, email=?, address=? WHERE id=?");
        $stmt->bind_param('sssi', $name, $email, $address, $user['id']);
        $stmt->execute();
        $stmt->close();

        if ($newPass !== '') {
            if (strlen($newPass) < 6) {
                flash('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।', 'error');
            } else {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt->bind_param('si', $hash, $user['id']);
                $stmt->execute();
                $stmt->close();
            }
        }
        flash('তথ্য সেভ হয়েছে।');
    }
    redirect('account.php');
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$stmt->bind_param('i', $user['id']);
$stmt->execute();
$orders = $stmt->get_result();
$stmt->close();

$__title = 'আমার অ্যাকাউন্ট — Aschi';
require_once __DIR__ . '/includes/header.php';
?>
<main class="container py-4">
  <h1 class="h4 fw-bold mb-4">আমার অ্যাকাউন্ট</h1>

  <div class="row g-4">
    <div class="col-lg-5">
      <div class="card-soft p-3">
        <h2 class="h6 fw-bold mb-3">প্রোফাইল</h2>
        <form method="post">
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label" for="name">নাম</label>
            <input class="form-control" id="name" name="name" value="<?= h($user['name']) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label" for="phone">মোবাইল নাম্বার</label>
            <input class="form-control" id="phone" value="<?= h($user['phone']) ?>" disabled>
            <div class="form-text">নাম্বার বদলাতে সাপোর্টে যোগাযোগ করুন।</div>
          </div>
          <div class="mb-3">
            <label class="form-label" for="email">ইমেইল</label>
            <input class="form-control" id="email" name="email" type="email" value="<?= h($user['email']) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label" for="address">ঠিকানা</label>
            <textarea class="form-control" id="address" name="address" rows="3"><?= h($user['address']) ?></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label" for="password">নতুন পাসওয়ার্ড (বদলাতে চাইলে)</label>
            <input class="form-control" id="password" name="password" type="password" autocomplete="new-password">
          </div>
          <button class="btn btn-green w-100">তথ্য সেভ করুন</button>
        </form>
      </div>
    </div>

    <div class="col-lg-7" id="orders">
      <div class="card-soft p-3">
        <h2 class="h6 fw-bold mb-3">অর্ডার হিস্টোরি</h2>
        <?php if (!$orders->num_rows): ?>
          <p class="text-muted mb-2">এখনো কোনো অর্ডার নেই।</p>
          <a href="<?= url('products.php') ?>" class="btn btn-outline-green btn-sm">বাজার শুরু করুন</a>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table align-middle">
              <thead class="table-light">
                <tr><th>অর্ডার</th><th>তারিখ</th><th>মোট</th><th>স্ট্যাটাস</th><th></th></tr>
              </thead>
              <tbody>
              <?php while ($o = $orders->fetch_assoc()): ?>
                <tr>
                  <td class="fw-semibold"><?= h($o['order_code']) ?></td>
                  <td class="text-muted small"><?= date('d M Y', strtotime($o['created_at'])) ?></td>
                  <td><?= taka($o['total']) ?></td>
                  <td><span class="badge bg-<?= status_color($o['order_status']) ?>"><?= h(status_label($o['order_status'])) ?></span></td>
                  <td class="text-end">
                    <a class="btn btn-sm btn-outline-green" href="<?= url('track-order.php?code=' . urlencode($o['order_code'])) ?>">ট্র্যাক</a>
                  </td>
                </tr>
              <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</main>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
