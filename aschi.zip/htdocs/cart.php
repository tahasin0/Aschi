<?php
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (isset($_POST['remove']))       { cart_remove((int)$_POST['remove']); flash('পণ্যটি সরানো হয়েছে।'); }
    elseif (isset($_POST['clear']))    { cart_clear(); flash('কার্ট খালি করা হয়েছে।'); }
    redirect('cart.php');
}

$items    = cart_items();
$subtotal = 0;
foreach ($items as $i) $subtotal += $i['line'];
$charge = $items ? delivery_charge_for($subtotal) : 0;

$__title = 'আমার কার্ট — Aschi';
require_once __DIR__ . '/includes/header.php';
?>

<main class="container py-4">
  <h1 class="h4 fw-bold mb-4">আমার কার্ট</h1>

  <?php if (!$items): ?>
    <div class="card-soft p-5 text-center">
      <div style="font-size:48px">🛒</div>
      <h2 class="h5 fw-bold mt-2">কার্ট এখনো খালি</h2>
      <p class="text-muted">পছন্দের পণ্য যোগ করে অর্ডার শুরু করুন।</p>
      <a href="<?= url('products.php') ?>" class="btn btn-green">বাজার শুরু করুন</a>
    </div>
  <?php else: ?>
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="card-soft p-0 overflow-hidden">
        <table class="table align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th>পণ্য</th>
              <th class="text-center d-none d-md-table-cell">দাম</th>
              <th class="text-center">পরিমাণ</th>
              <th class="text-end">মোট</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($items as $it): ?>
            <tr>
              <td>
                <div class="d-flex gap-2 align-items-center">
                  <img src="<?= product_image($it['image']) ?>" alt="" width="56" height="56"
                       class="rounded-3" style="object-fit:cover">
                  <div>
                    <a class="fw-semibold text-reset" href="<?= url('product-details.php?id=' . (int)$it['id']) ?>"><?= h($it['name']) ?></a>
                    <div class="text-muted small"><?= taka($it['price']) ?> / <?= h($it['unit']) ?></div>
                  </div>
                </div>
              </td>
              <td class="text-center d-none d-md-table-cell"><?= taka($it['price']) ?></td>
              <td class="text-center">
                <div class="qty-box">
                  <button type="button" class="js-qty-step" data-step="-1" aria-label="কমান">−</button>
                  <input class="js-qty js-cart-qty" data-id="<?= (int)$it['id'] ?>" type="number"
                         value="<?= (int)$it['qty'] ?>" min="1" max="<?= (int)$it['stock'] ?>" inputmode="numeric">
                  <button type="button" class="js-qty-step" data-step="1" aria-label="বাড়ান">+</button>
                </div>
              </td>
              <td class="text-end fw-semibold"><?= taka($it['line']) ?></td>
              <td class="text-end">
                <form method="post" onsubmit="return confirm('পণ্যটি কার্ট থেকে সরাবেন?')">
                  <?= csrf_field() ?>
                  <button class="btn btn-sm btn-outline-danger" name="remove" value="<?= (int)$it['id'] ?>" aria-label="সরান">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="d-flex justify-content-between mt-3">
        <a href="<?= url('products.php') ?>" class="btn btn-outline-green">আরও কিনুন</a>
        <form method="post"><?= csrf_field() ?>
          <button class="btn btn-outline-danger" name="clear" value="1">কার্ট খালি করুন</button>
        </form>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="card-soft p-3">
        <h2 class="h6 fw-bold mb-3">অর্ডার সারসংক্ষেপ</h2>
        <div class="d-flex justify-content-between mb-2">
          <span class="text-muted">সাবটোটাল</span><span><?= taka($subtotal) ?></span>
        </div>
        <div class="d-flex justify-content-between mb-2">
          <span class="text-muted">ডেলিভারি চার্জ</span>
          <span><?= $charge > 0 ? taka($charge) : 'ফ্রি' ?></span>
        </div>
        <hr>
        <div class="d-flex justify-content-between fw-bold fs-5">
          <span>সর্বমোট</span><span class="text-green"><?= taka($subtotal + $charge) ?></span>
        </div>

        <?php if (ordering_open()): ?>
          <a href="<?= url('checkout.php') ?>" class="btn btn-green w-100 mt-3">চেকআউটে যান</a>
        <?php else: ?>
          <button class="btn btn-green w-100 mt-3" disabled>অর্ডার বন্ধ আছে</button>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
