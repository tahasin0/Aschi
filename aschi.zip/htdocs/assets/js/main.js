/* Aschi — customer site scripts */
(function () {
  'use strict';

  /* ---- Splash loader: hide after page load (max 2.5s) ---- */
  var loader = document.getElementById('aschi-loader');
  if (loader) {
    var hide = function () { loader.classList.add('hide'); };
    window.addEventListener('load', function () { setTimeout(hide, 900); });
    setTimeout(hide, 2500); // safety net on slow assets
  }

  /* ---- Toast ---- */
  function toast(message, ok) {
    var box = document.getElementById('aschi-toast');
    if (!box) {
      box = document.createElement('div');
      box.id = 'aschi-toast';
      box.style.cssText = 'position:fixed;left:50%;bottom:96px;transform:translateX(-50%);' +
        'z-index:2000;padding:12px 20px;border-radius:12px;color:#fff;font-weight:600;' +
        'box-shadow:0 8px 24px rgba(0,0,0,.18);display:none;max-width:90vw;text-align:center';
      document.body.appendChild(box);
    }
    box.style.background = ok === false ? '#B42318' : '#16A34A';
    box.textContent = message;
    box.style.display = 'block';
    clearTimeout(box._t);
    box._t = setTimeout(function () { box.style.display = 'none'; }, 2600);
  }
  window.aschiToast = toast;

  function setCartCount(n) {
    document.querySelectorAll('.js-cart-count').forEach(function (el) {
      el.textContent = n;
      el.style.display = n > 0 ? '' : 'none';
    });
  }

  /* ---- Add to cart (AJAX, stays on the page) ---- */
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.js-add-cart');
    if (!btn) return;
    e.preventDefault();

    var qtyInput = btn.form ? btn.form.querySelector('.js-qty') : null;
    var data = new FormData();
    data.append('action', 'add');
    data.append('product_id', btn.dataset.id);
    data.append('qty', qtyInput ? qtyInput.value : (btn.dataset.qty || 1));
    data.append('csrf', window.ASCHI_CSRF || '');

    btn.disabled = true;
    fetch(window.ASCHI_BASE + '/ajax/cart_action.php', { method: 'POST', body: data })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        btn.disabled = false;
        if (res.ok) { setCartCount(res.count); toast(res.message); }
        else { toast(res.message || 'যোগ করা যায়নি।', false); }
      })
      .catch(function () { btn.disabled = false; toast('সংযোগে সমস্যা হয়েছে।', false); });
  });

  /* ---- Quantity +/- ---- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('.js-qty-step');
    if (!b) return;
    var input = b.parentElement.querySelector('.js-qty');
    if (!input) return;
    var val = parseInt(input.value, 10) || 1;
    val += parseInt(b.dataset.step, 10);
    var max = parseInt(input.getAttribute('max'), 10);
    if (val < 1) val = 1;
    if (max && val > max) { val = max; toast('স্টকে এর বেশি নেই।', false); }
    input.value = val;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });

  /* ---- Cart page: quantity change updates line + totals ---- */
  document.addEventListener('change', function (e) {
    var input = e.target.closest('.js-cart-qty');
    if (!input) return;
    var data = new FormData();
    data.append('action', 'update');
    data.append('product_id', input.dataset.id);
    data.append('qty', input.value);
    data.append('csrf', window.ASCHI_CSRF || '');

    fetch(window.ASCHI_BASE + '/ajax/cart_action.php', { method: 'POST', body: data })
      .then(function (r) { return r.json(); })
      .then(function (res) { if (res.ok) location.reload(); else toast(res.message, false); });
  });

  /* ---- Lazy loading fallback for older browsers ---- */
  if (!('loading' in HTMLImageElement.prototype)) {
    document.querySelectorAll('img[loading="lazy"]').forEach(function (img) {
      img.src = img.dataset.src || img.src;
    });
  }
})();
