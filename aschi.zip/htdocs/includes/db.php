<?php
/**
 * Aschi — database connection (MySQLi)
 * Edit the four constants below to match your hosting cPanel credentials.
 */

define('DB_HOST', 'sql300.infinityfree.com');
define('DB_USER', 'if0_42985470');
define('DB_PASS', 'NhJq3kd7eALJ');
define('DB_NAME', 'if0_42985470_t');

// Base URL of the project (no trailing slash). Example: https://aschi.com.bd
define('BASE_URL', 'https://aschidemo.free.nf/');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    // Never print raw DB errors to the customer.
    error_log('Aschi DB error: ' . $e->getMessage());
    die('ডেটাবেজ সংযোগে সমস্যা হয়েছে। একটু পরে আবার চেষ্টা করুন।');
}

date_default_timezone_set('Asia/Dhaka');
