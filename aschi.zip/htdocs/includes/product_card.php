<?php
/** Reusable product card. Expects $p (product row). */
$__open = ordering_open();
?>
<div class="product-card">
  <a class="thumb d-block" href="<?= url('product-details.php?id=' . (int)$p['id']) ?>">
    <img src="<?= product_image($p['image']) ?>" alt="<?= h($p['name']) ?>" loading="lazy">
  </a>
  <div class="body">
    <h3 class="p-name">
      <a href="<?= url('product-details.php?id=' . (int)$p['id']) ?>" class="text-reset"><?= h($p['name']) ?></a>
    </h3>
    <div>
      <span class="price"><?= taka($p['price']) ?></span>
      <?php if (!empty($p['old_price']) && $p['old_price'] > $p['price']): ?>
        <span class="old-price"><?= taka($p['old_price']) ?></span>
      <?php endif; ?>
      <span class="unit">/ <?= h($p['unit']) ?></span>
    </div>
    <div class="mt-auto">
      <?php if ((int)$p['stock'] <= 0): ?>
        <div class="stock-out mb-2">স্টকে নেই</div>
        <button class="btn btn-outline-green w-100" disabled>কার্টে যোগ করুন</button>
      <?php else: ?>
        <button class="btn btn-green w-100 js-add-cart" data-id="<?= (int)$p['id'] ?>" data-qty="1" <?= $__open ? '' : 'disabled' ?>>
          <i class="bi bi-cart-plus"></i> কার্টে যোগ করুন
        </button>
      <?php endif; ?>
    </div>
  </div>
</div>
