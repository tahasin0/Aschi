<?php
/**
 * Aschi — shared helper functions.
 * Included by every page (after db.php).
 */

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

require_once __DIR__ . '/db.php';

/* ---------------------------------------------------------
   Output / URL helpers
--------------------------------------------------------- */

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function url($path = '') {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function redirect($path) {
    header('Location: ' . (strpos($path, 'http') === 0 ? $path : url($path)));
    exit;
}

/** Format money in Bangla-friendly form: ৳ 1,250.00 */
function taka($amount) {
    return '৳ ' . number_format((float)$amount, 2);
}

/** Convert English digits to Bangla digits for display */
function bn_num($str) {
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
    return str_replace($en, $bn, (string)$str);
}

function product_image($file) {
    if ($file && file_exists(__DIR__ . '/../assets/images/products/' . $file)) {
        return url('assets/images/products/' . $file);
    }
    return url('assets/images/placeholder.svg');
}

/* ---------------------------------------------------------
   Settings (key/value store)
--------------------------------------------------------- */

function setting($key, $default = '') {
    global $conn;
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $res = $conn->query("SELECT setting_key, setting_value FROM settings");
        while ($row = $res->fetch_assoc()) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function save_setting($key, $value) {
    global $conn;
    $stmt = $conn->prepare(
        "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
    );
    $stmt->bind_param('ss', $key, $value);
    $stmt->execute();
    $stmt->close();
}

/** Global ordering switch */
function ordering_open() {
    return setting('order_status_global', 'on') === 'on';
}

/* ---------------------------------------------------------
   CSRF protection
--------------------------------------------------------- */

function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function csrf_check() {
    $token = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $token)) {
        http_response_code(419);
        die('সেশন মেয়াদ শেষ হয়েছে। পেজটি রিফ্রেশ করে আবার চেষ্টা করুন।');
    }
}

/* ---------------------------------------------------------
   Flash messages
--------------------------------------------------------- */

function flash($msg = null, $type = 'success') {
    if ($msg !== null) {
        $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
        return null;
    }
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/* ---------------------------------------------------------
   Customer auth
--------------------------------------------------------- */

function current_user() {
    global $conn;
    if (empty($_SESSION['user_id'])) return null;
    static $user = null;
    if ($user === null) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND status='active'");
        $stmt->bind_param('i', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc() ?: null;
        $stmt->close();
    }
    return $user;
}

function require_login() {
    if (!current_user()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        redirect('login.php');
    }
}

function valid_bd_phone($phone) {
    return (bool)preg_match('/^01[3-9]\d{8}$/', $phone);
}

/* ---------------------------------------------------------
   Cart (session based, works for guests and members)
   Structure: $_SESSION['cart'][product_id] = quantity
--------------------------------------------------------- */

function cart_items() {
    global $conn;
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];

    $ids = array_map('intval', array_keys($cart));
    $in  = implode(',', $ids);
    $res = $conn->query("SELECT * FROM products WHERE id IN ($in) AND status='active'");

    $items = [];
    while ($p = $res->fetch_assoc()) {
        $qty = (int)$cart[$p['id']];
        if ($qty < 1) continue;
        if ($p['stock'] > 0 && $qty > $p['stock']) $qty = (int)$p['stock'];
        $p['qty']  = $qty;
        $p['line'] = $qty * (float)$p['price'];
        $items[]   = $p;
    }
    return $items;
}

function cart_count() {
    return array_sum($_SESSION['cart'] ?? []);
}

function cart_subtotal() {
    $sum = 0;
    foreach (cart_items() as $i) $sum += $i['line'];
    return $sum;
}

function cart_add($product_id, $qty = 1) {
    $product_id = (int)$product_id;
    $qty = max(1, (int)$qty);
    if (!isset($_SESSION['cart'][$product_id])) $_SESSION['cart'][$product_id] = 0;
    $_SESSION['cart'][$product_id] += $qty;
}

function cart_set($product_id, $qty) {
    $product_id = (int)$product_id;
    $qty = (int)$qty;
    if ($qty < 1) unset($_SESSION['cart'][$product_id]);
    else $_SESSION['cart'][$product_id] = $qty;
}

function cart_remove($product_id) {
    unset($_SESSION['cart'][(int)$product_id]);
}

function cart_clear() {
    $_SESSION['cart'] = [];
}

/** Delivery charge for a given subtotal */
function delivery_charge_for($subtotal) {
    $free_above = (float)setting('free_delivery_above', 0);
    if ($free_above > 0 && $subtotal >= $free_above) return 0.0;
    return (float)setting('delivery_charge', 0);
}

/* ---------------------------------------------------------
   Orders
--------------------------------------------------------- */

function generate_order_code() {
    return 'ASC' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
}

function order_statuses() {
    return [
        'pending'        => 'অর্ডার পেন্ডিং',
        'confirmed'      => 'কনফার্ম হয়েছে',
        'rider_assigned' => 'রাইডার নিযুক্ত',
        'picked_up'      => 'পণ্য সংগ্রহ হয়েছে',
        'on_the_way'     => 'পথে আছে',
        'delivered'      => 'ডেলিভারি সম্পন্ন',
        'cancelled'      => 'বাতিল',
    ];
}

function status_label($key) {
    $s = order_statuses();
    return $s[$key] ?? $key;
}

function status_color($key) {
    return [
        'pending' => 'secondary', 'confirmed' => 'info', 'rider_assigned' => 'primary',
        'picked_up' => 'primary', 'on_the_way' => 'warning',
        'delivered' => 'success', 'cancelled' => 'danger',
    ][$key] ?? 'secondary';
}

function payment_status_label($key) {
    return [
        'not_required' => 'প্রযোজ্য নয়',
        'pending'      => 'অ্যাপ্রুভাল পেন্ডিং',
        'approved'     => 'অ্যাপ্রুভড',
        'rejected'     => 'রিজেক্টেড',
    ][$key] ?? $key;
}

function log_status_change($order_id, $status, $by = 'admin') {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO order_status_history (order_id, status, changed_by) VALUES (?,?,?)");
    $stmt->bind_param('iss', $order_id, $status, $by);
    $stmt->execute();
    $stmt->close();
}

/* ---------------------------------------------------------
   Uploads
--------------------------------------------------------- */

/**
 * Handle an image upload. Returns the stored filename, or null.
 * $folder e.g. 'products', 'riders', 'banners', 'categories'
 */
function upload_image($field, $folder) {
    if (empty($_FILES[$field]['name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $info = getimagesize($_FILES[$field]['tmp_name']);
    if (!$info || !isset($allowed[$info['mime']])) return null;
    if ($_FILES[$field]['size'] > 4 * 1024 * 1024) return null;   // 4 MB cap

    $name = $folder . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$info['mime']];
    $dest = __DIR__ . '/../assets/images/' . $folder . '/' . $name;
    if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) return $name;
    return null;
}

function delete_image($file, $folder) {
    if (!$file) return;
    $path = __DIR__ . '/../assets/images/' . $folder . '/' . basename($file);
    if (is_file($path)) @unlink($path);
}

/**
 * Handle a multi-file upload (<input type="file" name="gallery[]" multiple>).
 * Returns an array of stored filenames; invalid files are skipped silently.
 */
function upload_images($field, $folder, $max = 6) {
    if (empty($_FILES[$field]['name'][0])) return [];

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $saved = [];
    $count = count($_FILES[$field]['name']);

    for ($i = 0; $i < $count && count($saved) < $max; $i++) {
        if ($_FILES[$field]['error'][$i] !== UPLOAD_ERR_OK) continue;
        if ($_FILES[$field]['size'][$i] > 4 * 1024 * 1024) continue;

        $info = getimagesize($_FILES[$field]['tmp_name'][$i]);
        if (!$info || !isset($allowed[$info['mime']])) continue;

        $name = $folder . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$info['mime']];
        $dest = __DIR__ . '/../assets/images/' . $folder . '/' . $name;
        if (move_uploaded_file($_FILES[$field]['tmp_name'][$i], $dest)) $saved[] = $name;
    }
    return $saved;
}

/* ---------------------------------------------------------
   Brute force protection
--------------------------------------------------------- */

function client_ip() {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function record_login_attempt($username) {
    global $conn;
    $ip = client_ip();
    $stmt = $conn->prepare("INSERT INTO login_attempts (ip, username) VALUES (?,?)");
    $stmt->bind_param('ss', $ip, $username);
    $stmt->execute();
    $stmt->close();
}

/** true when the IP has made 5+ failed attempts in the last 15 minutes */
function login_blocked() {
    global $conn;
    $ip = client_ip();
    $stmt = $conn->prepare(
        "SELECT COUNT(*) c FROM login_attempts
         WHERE ip = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)"
    );
    $stmt->bind_param('s', $ip);
    $stmt->execute();
    $c = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();
    return $c >= 5;
}

function clear_login_attempts() {
    global $conn;
    $ip = client_ip();
    $stmt = $conn->prepare("DELETE FROM login_attempts WHERE ip = ?");
    $stmt->bind_param('s', $ip);
    $stmt->execute();
    $stmt->close();
}
