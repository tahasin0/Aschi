<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi" style="height:56px">
        <p class="text-muted mt-2 mb-0" style="max-width:38ch">
          কাঁচাবাজার, সবজি, মাছ, মাংস আর দৈনন্দিন প্রয়োজনীয় পণ্য — অর্ডার দিন, আমরা পৌঁছে দেব।
        </p>
      </div>
      <div class="col-6 col-md-3">
        <h6>শপিং</h6>
        <a href="<?= url('products.php') ?>">সব পণ্য</a>
        <a href="<?= url('cart.php') ?>">কার্ট</a>
        <a href="<?= url('track-order.php') ?>">অর্ডার ট্র্যাক করুন</a>
      </div>
      <div class="col-6 col-md-3">
        <h6>অ্যাকাউন্ট</h6>
        <a href="<?= url('login.php') ?>">লগইন</a>
        <a href="<?= url('register.php') ?>">রেজিস্ট্রেশন</a>
        <a href="<?= url('account.php') ?>">আমার অর্ডার</a>
      </div>
      <div class="col-md-2">
        <h6>যোগাযোগ</h6>
        <a href="tel:<?= h(setting('support_phone')) ?>"><?= h(setting('support_phone')) ?></a>
        <span class="text-muted small d-block mt-1"><?= h(setting('contact_address')) ?></span>
      </div>
    </div>
    <hr class="my-4">
    <p class="text-muted small mb-0">© <?= date('Y') ?> Aschi. সর্বস্বত্ব সংরক্ষিত।</p>
  </div>
</footer>

<?php if ($link = trim(setting('support_link'))): ?>
<a class="support-fab" href="<?= h($link) ?>" target="_blank" rel="noopener" aria-label="সাপোর্টে মেসেজ করুন">
  <i class="bi bi-whatsapp"></i>
</a>
<?php endif; ?>

<nav class="bottom-nav">
  <a href="<?= url('index.php') ?>" class="<?= $__page === 'index.php' ? 'active' : '' ?>"><i class="bi bi-house"></i>হোম</a>
  <a href="<?= url('products.php') ?>" class="<?= $__page === 'products.php' ? 'active' : '' ?>"><i class="bi bi-grid"></i>ক্যাটেগরি</a>
  <a href="<?= url('cart.php') ?>" class="<?= $__page === 'cart.php' ? 'active' : '' ?>"><i class="bi bi-cart3"></i>কার্ট</a>
  <a href="<?= url('account.php') ?>" class="<?= $__page === 'account.php' ? 'active' : '' ?>"><i class="bi bi-person"></i>অ্যাকাউন্ট</a>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= url('assets/js/main.js') ?>"></script>
</body>
</html>
