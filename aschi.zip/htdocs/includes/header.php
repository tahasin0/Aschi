<?php
require_once __DIR__ . '/functions.php';
$__user  = current_user();
$__page  = basename($_SERVER['PHP_SELF']);
$__title = $__title ?? 'Aschi — তাজা বাজার, দরজায় পৌঁছে যাবে';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($__title) ?></title>
<meta name="description" content="কাঁচাবাজার, সবজি, মাছ, মাংস ও দৈনন্দিন পণ্য অনলাইনে অর্ডার করুন — Aschi পৌঁছে দেবে আপনার দরজায়।">
<link rel="icon" href="<?= url('assets/images/logo.png') ?>">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Poppins:wght@500;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>

<?php if (setting('loader_enabled', '1') === '1'): ?>
<div id="aschi-loader">
  <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi">
  <div class="road"><span class="bike">🛵</span></div>
  <div class="loader-text">আপনার বাজার আসছে…</div>
</div>
<?php endif; ?>

<?php $bannerText = trim(setting('banner_text')); if ($bannerText !== ''): ?>
<div class="ticker <?= setting('banner_direction','left') === 'right' ? 'ticker--right' : '' ?>"
     style="--ticker-speed: <?= (int)setting('banner_speed', 35) ?>s">
  <div class="ticker__track"><?= h($bannerText) ?></div>
</div>
<?php endif; ?>

<header class="site-header">
  <div class="container py-2">
    <div class="d-flex align-items-center gap-3">

      <a class="logo d-flex align-items-center" href="<?= url('index.php') ?>">
        <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi">
      </a>

      <form class="search-box flex-grow-1 d-none d-md-block" action="<?= url('products.php') ?>" method="get" role="search">
        <input type="search" name="q" class="form-control" placeholder="কী খুঁজছেন? যেমন — আলু, রুই মাছ…"
               value="<?= h($_GET['q'] ?? '') ?>" aria-label="পণ্য খুঁজুন">
      </form>

      <div class="ms-auto d-flex align-items-center gap-2">
        <a href="<?= url('cart.php') ?>" class="btn btn-outline-green cart-btn" aria-label="কার্ট">
          <i class="bi bi-cart3"></i>
          <span class="badge js-cart-count" <?= cart_count() ? '' : 'style="display:none"' ?>><?= cart_count() ?></span>
        </a>

        <?php if ($__user): ?>
          <div class="dropdown">
            <button class="btn btn-green dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-person"></i> <span class="d-none d-sm-inline"><?= h($__user['name']) ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="<?= url('account.php') ?>">আমার অ্যাকাউন্ট</a></li>
              <li><a class="dropdown-item" href="<?= url('account.php#orders') ?>">অর্ডার হিস্টোরি</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="<?= url('logout.php') ?>">লগ আউট</a></li>
            </ul>
          </div>
        <?php else: ?>
          <a href="<?= url('login.php') ?>" class="btn btn-green"><i class="bi bi-person"></i> <span class="d-none d-sm-inline">লগইন</span></a>
        <?php endif; ?>
      </div>
    </div>

    <form class="search-box d-md-none mt-2" action="<?= url('products.php') ?>" method="get">
      <input type="search" name="q" class="form-control" placeholder="পণ্য খুঁজুন…" value="<?= h($_GET['q'] ?? '') ?>">
    </form>
  </div>
</header>

<?php if (!ordering_open()): ?>
<div class="container mt-3">
  <div class="notice-bar d-flex align-items-center gap-2">
    <i class="bi bi-clock-history fs-5"></i>
    <span><?= h(setting('order_off_message', 'এই মুহূর্তে অর্ডার নেওয়া বন্ধ আছে।')) ?></span>
  </div>
</div>
<?php endif; ?>

<?php if ($__f = flash()): ?>
<div class="container mt-3">
  <div class="alert alert-<?= $__f['type'] === 'error' ? 'danger' : $__f['type'] ?> mb-0"><?= h($__f['msg']) ?></div>
</div>
<?php endif; ?>

<script>
  window.ASCHI_BASE = '<?= rtrim(BASE_URL, "/") ?>';
  window.ASCHI_CSRF = '<?= csrf_token() ?>';
</script>
