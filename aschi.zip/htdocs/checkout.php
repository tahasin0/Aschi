<?php
require_once __DIR__ . '/includes/functions.php';

$user  = current_user();
$items = cart_items();

if (!$items) { flash('কার্ট খালি — আগে পণ্য যোগ করুন।', 'warning'); redirect('cart.php'); }
if (!ordering_open()) { flash(setting('order_off_message'), 'warning'); redirect('cart.php'); }

$subtotal      = array_sum(array_column($items, 'line'));
$advanceOn     = setting('advance_charge_enabled', '0') === '1';
$deliveryCharge = $advanceOn ? (float)setting('advance_charge_amount', 0) : delivery_charge_for($subtotal);
$total         = $subtotal + $deliveryCharge;

$errors = [];
$form = [
    'name'    => $user['name']    ?? '',
    'phone'   => $user['phone']   ?? '',
    'address' => $user['address'] ?? '',
    'note'    => '',
    'trx_id'  => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($form as $k => $_) $form[$k] = trim($_POST[$k] ?? '');

    if ($form['name'] === '')                 $errors['name']    = 'নাম লিখুন।';
    if (!valid_bd_phone($form['phone']))      $errors['phone']   = 'ফোন নাম্বার সঠিক নয় (যেমন ০১৭XXXXXXXX)।';
    if (mb_strlen($form['address']) < 10)     $errors['address'] = 'সম্পূর্ণ ঠিকানা লিখুন — বাসা/রোড/এলাকা সহ।';

    if ($advanceOn) {
        if ($form['trx_id'] === '') {
            $errors['trx_id'] = 'টাকা পাঠানোর পর Transaction ID (TRX ID) লিখুন।';
        } else {
            $stmt = $conn->prepare("SELECT id FROM orders WHERE trx_id = ?");
            $stmt->bind_param('s', $form['trx_id']);
            $stmt->execute();
            if ($stmt->get_result()->num_rows) $errors['trx_id'] = 'এই TRX ID আগেই ব্যবহার করা হয়েছে।';
            $stmt->close();
        }
    }

    // stock re-check just before saving
    foreach ($items as $it) {
        if ($it['qty'] > (int)$it['stock']) {
            $errors['stock'] = $it['name'] . ' — স্টকে পর্যাপ্ত নেই। কার্ট ঠিক করে আবার চেষ্টা করুন।';
        }
    }

    if (!$errors) {
        $code       = generate_order_code();
        $userId     = $user['id'] ?? null;
        $advReq     = $advanceOn ? 1 : 0;
        $advStatus  = $advanceOn ? 'pending' : 'not_required';
        $payNumber  = $advanceOn ? setting('payment_number') : null;
        $payMethod  = $advanceOn ? setting('payment_method_name') : 'ক্যাশ অন ডেলিভারি';
        $trx        = $advanceOn ? $form['trx_id'] : null;

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare(
                "INSERT INTO orders
                 (order_code, user_id, guest_name, guest_phone, guest_address, note,
                  subtotal, delivery_charge, total, advance_required, advance_paid_status,
                  trx_id, payment_number_used, payment_method, order_status)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending')"
            );
            $stmt->bind_param(
                'sissssdddissss',
                $code, $userId, $form['name'], $form['phone'], $form['address'], $form['note'],
                $subtotal, $deliveryCharge, $total, $advReq, $advStatus, $trx, $payNumber, $payMethod
            );
            $stmt->execute();
            $orderId = $conn->insert_id;
            $stmt->close();

            $itemStmt = $conn->prepare(
                "INSERT INTO order_items (order_id, product_id, product_name, unit, quantity, price)
                 VALUES (?,?,?,?,?,?)"
            );
            $stockStmt = $conn->prepare(
                "UPDATE products SET stock = stock - ?, sold_count = sold_count + ? WHERE id = ?"
            );
            foreach ($items as $it) {
                $itemStmt->bind_param('iissid', $orderId, $it['id'], $it['name'], $it['unit'], $it['qty'], $it['price']);
                $itemStmt->execute();
                $stockStmt->bind_param('iii', $it['qty'], $it['qty'], $it['id']);
                $stockStmt->execute();
            }
            $itemStmt->close();
            $stockStmt->close();

            log_status_change($orderId, 'pending', 'customer');
            $conn->commit();

            cart_clear();
            $_SESSION['last_order_code'] = $code;
            redirect('order-success.php?code=' . urlencode($code));

        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            error_log('Aschi order error: ' . $e->getMessage());
            $errors['general'] = 'অর্ডার সেভ করা যায়নি। একটু পরে আবার চেষ্টা করুন।';
        }
    }
}

$__title = 'চেকআউট — Aschi';
require_once __DIR__ . '/includes/header.php';
?>

<main class="container py-4">
  <h1 class="h4 fw-bold mb-4">চেকআউট</h1>

  <?php if (!empty($errors['general']) || !empty($errors['stock'])): ?>
    <div class="alert alert-danger"><?= h($errors['general'] ?? $errors['stock']) ?></div>
  <?php endif; ?>

  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="row g-4">
      <div class="col-lg-7">

        <div class="card-soft p-3 mb-3">
          <?php if ($user): ?>
            <div class="d-flex align-items-center gap-2 mb-3">
              <span class="badge badge-soft">লগইন করা আছে</span>
              <span class="text-muted small">আপনার সেভ করা তথ্য বসানো হয়েছে — দরকার হলে বদলে নিন।</span>
            </div>
          <?php else: ?>
            <div class="notice-bar mb-3">
              সমস্যা নাই — অ্যাকাউন্ট ছাড়াই অর্ডার করতে পারবেন। নিচের তথ্যগুলো দিলেই হবে।
              <a href="<?= url('login.php') ?>" class="fw-semibold">অথবা লগইন করুন</a>
            </div>
          <?php endif; ?>

          <h2 class="h6 fw-bold mb-3">ডেলিভারি তথ্য</h2>

          <div class="mb-3">
            <label class="form-label" for="name">নাম</label>
            <input class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" id="name" name="name"
                   value="<?= h($form['name']) ?>" required>
            <?php if (isset($errors['name'])): ?><div class="invalid-feedback"><?= h($errors['name']) ?></div><?php endif; ?>
          </div>

          <div class="mb-3">
            <label class="form-label" for="phone">মোবাইল নাম্বার</label>
            <input class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" id="phone" name="phone"
                   value="<?= h($form['phone']) ?>" inputmode="numeric" placeholder="01XXXXXXXXX" required>
            <?php if (isset($errors['phone'])): ?><div class="invalid-feedback"><?= h($errors['phone']) ?></div><?php endif; ?>
          </div>

          <div class="mb-3">
            <label class="form-label" for="address">পূর্ণ ঠিকানা</label>
            <textarea class="form-control <?= isset($errors['address']) ? 'is-invalid' : '' ?>" id="address" name="address"
                      rows="3" placeholder="বাসা নম্বর, রোড, এলাকা, থানা" required><?= h($form['address']) ?></textarea>
            <?php if (isset($errors['address'])): ?><div class="invalid-feedback"><?= h($errors['address']) ?></div><?php endif; ?>
          </div>

          <div>
            <label class="form-label" for="note">অতিরিক্ত নির্দেশনা (ঐচ্ছিক)</label>
            <textarea class="form-control" id="note" name="note" rows="2"
                      placeholder="যেমন — মাছ কেটে দেবেন, কলিং বেল নষ্ট"><?= h($form['note']) ?></textarea>
          </div>
        </div>

        <div class="card-soft p-3">
          <h2 class="h6 fw-bold mb-3">পেমেন্ট</h2>

          <?php if ($advanceOn): ?>
            <div class="bg-green-soft rounded-3 p-3 mb-3">
              <p class="mb-1 fw-semibold">অগ্রিম ডেলিভারি চার্জ দিতে হবে: <?= taka($deliveryCharge) ?></p>
              <p class="mb-1">
                <?= h(setting('payment_method_name')) ?> নাম্বার:
                <strong class="fs-5 text-green"><?= h(setting('payment_number')) ?></strong>
              </p>
              <p class="mb-0 small text-muted">
                উপরের নাম্বারে <strong>Send Money</strong> করুন, তারপর যে Transaction ID পাবেন সেটি নিচে লিখুন।
                পণ্যের বাকি টাকা ডেলিভারির সময় দেবেন।
              </p>
            </div>

            <label class="form-label" for="trx_id">Transaction ID (TRX ID)</label>
            <input class="form-control <?= isset($errors['trx_id']) ? 'is-invalid' : '' ?>" id="trx_id" name="trx_id"
                   value="<?= h($form['trx_id']) ?>" placeholder="যেমন 9F7A2K1LMN" required>
            <?php if (isset($errors['trx_id'])): ?><div class="invalid-feedback"><?= h($errors['trx_id']) ?></div><?php endif; ?>
            <p class="text-muted small mt-2 mb-0">
              অর্ডারটি অ্যাডমিন TRX ID যাচাই করার পর কনফার্ম হবে।
            </p>
          <?php else: ?>
            <div class="d-flex gap-2 align-items-center">
              <span style="font-size:26px">💵</span>
              <div>
                <div class="fw-semibold">ক্যাশ অন ডেলিভারি</div>
                <div class="text-muted small">পণ্য হাতে পেয়ে রাইডারকে টাকা দেবেন।</div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="card-soft p-3">
          <h2 class="h6 fw-bold mb-3">আপনার অর্ডার</h2>
          <?php foreach ($items as $it): ?>
            <div class="d-flex justify-content-between mb-2">
              <span><?= h($it['name']) ?> <span class="text-muted small">× <?= bn_num($it['qty']) ?></span></span>
              <span><?= taka($it['line']) ?></span>
            </div>
          <?php endforeach; ?>
          <hr>
          <div class="d-flex justify-content-between mb-2">
            <span class="text-muted">সাবটোটাল</span><span><?= taka($subtotal) ?></span>
          </div>
          <div class="d-flex justify-content-between mb-2">
            <span class="text-muted">ডেলিভারি চার্জ</span>
            <span><?= $deliveryCharge > 0 ? taka($deliveryCharge) : 'ফ্রি' ?></span>
          </div>
          <hr>
          <div class="d-flex justify-content-between fw-bold fs-5">
            <span>সর্বমোট</span><span class="text-green"><?= taka($total) ?></span>
          </div>
          <button class="btn btn-green w-100 mt-3 py-2">অর্ডার কনফার্ম করুন</button>
          <a href="<?= url('cart.php') ?>" class="btn btn-link w-100 text-muted">কার্টে ফিরে যান</a>
        </div>
      </div>
    </div>
  </form>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
