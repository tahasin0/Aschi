<?php
require_once __DIR__ . '/includes/functions.php';
unset($_SESSION['user_id']);
session_regenerate_id(true);
flash('লগ আউট হয়েছে।');
redirect('index.php');
