<?php
/**
 * Aschi — one-time setup.
 *
 * Run this ONCE after importing schema.sql to create the first admin account,
 * then DELETE this file. It refuses to run if an admin already exists.
 */
require_once __DIR__ . '/includes/functions.php';

$adminCount = (int)$conn->query("SELECT COUNT(*) c FROM admins")->fetch_assoc()['c'];
$done   = false;
$errors = [];
$f = ['name' => '', 'username' => ''];

if ($adminCount > 0) {
    $errors['locked'] = 'অ্যাডমিন অ্যাকাউন্ট আগেই তৈরি হয়েছে। নিরাপত্তার জন্য এখনই এই ফাইলটি (install.php) সার্ভার থেকে মুছে ফেলুন।';
}

if (!$errors && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f['name']     = trim($_POST['name'] ?? '');
    $f['username'] = trim($_POST['username'] ?? '');
    $password      = $_POST['password'] ?? '';
    $confirm       = $_POST['confirm'] ?? '';

    if (!preg_match('/^[a-zA-Z0-9_.]{3,50}$/', $f['username'])) {
        $errors['username'] = 'ইউজারনেম ৩-৫০ অক্ষরের হতে হবে — শুধু ইংরেজি অক্ষর, সংখ্যা, _ বা . ব্যবহার করুন।';
    }
    if (strlen($password) < 8)   $errors['password'] = 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।';
    if ($password !== $confirm)  $errors['confirm']  = 'দুইবার লেখা পাসওয়ার্ড মিলছে না।';

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $name = $f['name'] !== '' ? $f['name'] : 'Super Admin';
        $stmt = $conn->prepare("INSERT INTO admins (name, username, password, role, status) VALUES (?,?,?,'admin','active')");
        $stmt->bind_param('sss', $name, $f['username'], $hash);
        $stmt->execute();
        $stmt->close();
        $done = true;
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Aschi সেটআপ</title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body style="background:#F5F7F6">
<div class="container" style="max-width:480px;padding-top:7vh">

  <div class="text-center mb-3">
    <img src="<?= url('assets/images/logo.png') ?>" alt="Aschi" style="height:84px">
  </div>

  <div class="card-soft p-4">
    <?php if (!empty($errors['locked'])): ?>

      <h1 class="h6 fw-bold mb-2">সেটআপ ইতিমধ্যে সম্পন্ন</h1>
      <div class="alert alert-warning"><?= h($errors['locked']) ?></div>
      <a class="btn btn-green w-100" href="<?= url('admin/login.php') ?>">অ্যাডমিন লগইনে যান</a>

    <?php elseif ($done): ?>

      <h1 class="h6 fw-bold mb-2">অ্যাকাউন্ট তৈরি হয়েছে</h1>
      <p class="text-muted">ইউজারনেম <strong><?= h($f['username']) ?></strong> দিয়ে ম্যানেজার প্যানেলে লগইন করুন।</p>
      <div class="alert alert-danger">
        <strong>শেষ ধাপ:</strong> এখনই সার্ভার থেকে <code>install.php</code> ফাইলটি মুছে ফেলুন।
        ফাইলটি রয়ে গেলে সেটআপ পেজটি খোলা থেকে যায়।
      </div>
      <a class="btn btn-green w-100" href="<?= url('admin/login.php') ?>">লগইন করুন</a>

    <?php else: ?>

      <h1 class="h6 fw-bold mb-1">প্রথম অ্যাডমিন অ্যাকাউন্ট</h1>
      <p class="text-muted small">
        নিরাপত্তার জন্য কোনো ডিফল্ট পাসওয়ার্ড রাখা হয়নি — আপনি নিজে ঠিক করুন।
        এই অ্যাকাউন্টটি সব কিছুতে অ্যাক্সেস পাবে।
      </p>

      <form method="post" novalidate>
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label" for="name">নাম</label>
          <input class="form-control" id="name" name="name" value="<?= h($f['name']) ?>" placeholder="যেমন — রায়হান">
        </div>
        <div class="mb-3">
          <label class="form-label" for="username">ইউজারনেম</label>
          <input class="form-control <?= isset($errors['username']) ? 'is-invalid' : '' ?>" id="username" name="username"
                 value="<?= h($f['username']) ?>" required autofocus>
          <?php if (isset($errors['username'])): ?><div class="invalid-feedback"><?= h($errors['username']) ?></div><?php endif; ?>
        </div>
        <div class="mb-3">
          <label class="form-label" for="password">পাসওয়ার্ড</label>
          <input class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" id="password" name="password"
                 type="password" autocomplete="new-password" required>
          <?php if (isset($errors['password'])): ?><div class="invalid-feedback"><?= h($errors['password']) ?></div><?php endif; ?>
          <div class="form-text">কমপক্ষে ৮ অক্ষর। অক্ষর, সংখ্যা ও চিহ্ন মিলিয়ে দিলে সবচেয়ে ভালো।</div>
        </div>
        <div class="mb-3">
          <label class="form-label" for="confirm">পাসওয়ার্ড আবার লিখুন</label>
          <input class="form-control <?= isset($errors['confirm']) ? 'is-invalid' : '' ?>" id="confirm" name="confirm"
                 type="password" autocomplete="new-password" required>
          <?php if (isset($errors['confirm'])): ?><div class="invalid-feedback"><?= h($errors['confirm']) ?></div><?php endif; ?>
        </div>
        <button class="btn btn-green w-100">অ্যাকাউন্ট তৈরি করুন</button>
      </form>

    <?php endif; ?>
  </div>

  <p class="text-center text-muted small mt-3"><a href="<?= url('index.php') ?>">← সাইট দেখুন</a></p>
</div>
</body>
</html>
