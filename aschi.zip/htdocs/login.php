<?php
require_once __DIR__ . '/includes/functions.php';
if (current_user()) redirect('account.php');

$error = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if (login_blocked()) {
        $error = 'অনেকবার ভুল হয়েছে। ১৫ মিনিট পর আবার চেষ্টা করুন।';
    } elseif (!valid_bd_phone($phone)) {
        $error = 'ফোন নাম্বার সঠিক নয়।';
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE phone = ? AND status='active'");
        $stmt->bind_param('s', $phone);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($u && password_verify($password, $u['password'])) {
            session_regenerate_id(true);
            clear_login_attempts();
            $_SESSION['user_id'] = $u['id'];
            $next = $_SESSION['redirect_after_login'] ?? null;
            unset($_SESSION['redirect_after_login']);
            flash('স্বাগতম, ' . $u['name'] . '!');
            redirect($next ?: 'account.php');
        }
        record_login_attempt($phone);
        $error = 'ফোন নাম্বার বা পাসওয়ার্ড মিলছে না।';
    }
}

$__title = 'লগইন — Aschi';
require_once __DIR__ . '/includes/header.php';
?>
<main class="container py-5">
  <div class="card-soft p-4 mx-auto" style="max-width:420px">
    <h1 class="h5 fw-bold mb-1">লগইন করুন</h1>
    <p class="text-muted small">ঠিকানা সেভ থাকলে পরের অর্ডার আরও দ্রুত হবে।</p>

    <?php if ($error): ?><div class="alert alert-danger py-2"><?= h($error) ?></div><?php endif; ?>

    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label" for="phone">মোবাইল নাম্বার</label>
        <input class="form-control" id="phone" name="phone" value="<?= h($phone) ?>" placeholder="01XXXXXXXXX" inputmode="numeric" required>
      </div>
      <div class="mb-3">
        <label class="form-label" for="password">পাসওয়ার্ড</label>
        <input class="form-control" id="password" name="password" type="password" required>
      </div>
      <button class="btn btn-green w-100">লগইন</button>
    </form>

    <p class="text-center text-muted small mt-3 mb-0">
      অ্যাকাউন্ট নেই? <a href="<?= url('register.php') ?>" class="fw-semibold">রেজিস্ট্রেশন করুন</a>
    </p>
  </div>
</main>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
