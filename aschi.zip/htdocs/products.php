<?php
require_once __DIR__ . '/includes/functions.php';
$__title = 'সব পণ্য — Aschi';
require_once __DIR__ . '/includes/header.php';

$cat   = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$q     = trim($_GET['q'] ?? '');
$sort  = $_GET['sort'] ?? 'new';
$page  = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset  = ($page - 1) * $perPage;

$orderBy = [
  'new'        => 'p.id DESC',
  'price_low'  => 'p.price ASC',
  'price_high' => 'p.price DESC',
  'popular'    => 'p.sold_count DESC, p.id DESC',
][$sort] ?? 'p.id DESC';

$where  = ["p.status='active'"];
$params = [];
$types  = '';

if ($cat)      { $where[] = 'p.category_id = ?'; $params[] = $cat; $types .= 'i'; }
if ($q !== '') { $where[] = '(p.name LIKE ? OR p.description LIKE ?)'; $like = '%' . $q . '%';
                 $params[] = $like; $params[] = $like; $types .= 'ss'; }
$whereSql = implode(' AND ', $where);

// total count
$stmt = $conn->prepare("SELECT COUNT(*) c FROM products p WHERE $whereSql");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = (int)$stmt->get_result()->fetch_assoc()['c'];
$stmt->close();

// page rows
$stmt = $conn->prepare("SELECT p.* FROM products p WHERE $whereSql ORDER BY $orderBy LIMIT ? OFFSET ?");
$p2 = $params; $p2[] = $perPage; $p2[] = $offset;
$stmt->bind_param($types . 'ii', ...$p2);
$stmt->execute();
$rows = $stmt->get_result();
$stmt->close();

$cats = $conn->query("SELECT * FROM categories WHERE status='active' ORDER BY sort_order, id");
$pages = max(1, (int)ceil($total / $perPage));

function qs(array $overrides = []) {
    return '?' . http_build_query(array_merge($_GET, $overrides));
}
?>

<main class="container py-4">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb small">
      <li class="breadcrumb-item"><a href="<?= url('index.php') ?>">হোম</a></li>
      <li class="breadcrumb-item active">পণ্য</li>
    </ol>
  </nav>

  <div class="row g-4">
    <aside class="col-lg-3">
      <div class="card-soft p-3">
        <h2 class="h6 fw-bold mb-3">ক্যাটেগরি</h2>
        <div class="list-group list-group-flush">
          <a class="list-group-item list-group-item-action <?= $cat === 0 ? 'fw-bold text-green' : '' ?>"
             href="<?= url('products.php') . qs(['cat' => null, 'page' => null]) ?>">সব পণ্য</a>
          <?php while ($c = $cats->fetch_assoc()): ?>
            <a class="list-group-item list-group-item-action <?= $cat === (int)$c['id'] ? 'fw-bold text-green' : '' ?>"
               href="<?= url('products.php') . qs(['cat' => $c['id'], 'page' => null]) ?>"><?= h($c['name']) ?></a>
          <?php endwhile; ?>
        </div>
      </div>
    </aside>

    <div class="col-lg-9">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <p class="mb-0 text-muted"><?= bn_num($total) ?>টি পণ্য পাওয়া গেছে<?= $q !== '' ? ' — “' . h($q) . '”' : '' ?></p>
        <form method="get" class="d-flex align-items-center gap-2">
          <?php foreach (['cat','q'] as $k): if (empty($_GET[$k])) continue; ?>
            <input type="hidden" name="<?= $k ?>" value="<?= h($_GET[$k]) ?>">
          <?php endforeach; ?>
          <label class="form-label mb-0" for="sort">সাজান</label>
          <select class="form-select" id="sort" name="sort" onchange="this.form.submit()" style="width:auto">
            <option value="new"        <?= $sort==='new'?'selected':'' ?>>নতুন আগে</option>
            <option value="popular"    <?= $sort==='popular'?'selected':'' ?>>জনপ্রিয়তা</option>
            <option value="price_low"  <?= $sort==='price_low'?'selected':'' ?>>দাম: কম থেকে বেশি</option>
            <option value="price_high" <?= $sort==='price_high'?'selected':'' ?>>দাম: বেশি থেকে কম</option>
          </select>
        </form>
      </div>

      <?php if (!$rows->num_rows): ?>
        <div class="card-soft p-5 text-center">
          <div style="font-size:44px">🧺</div>
          <h2 class="h5 fw-bold mt-2">এই ফিল্টারে কোনো পণ্য নেই</h2>
          <p class="text-muted">অন্য ক্যাটেগরি দেখুন বা অন্য নামে খুঁজুন।</p>
          <a href="<?= url('products.php') ?>" class="btn btn-green">সব পণ্য দেখুন</a>
        </div>
      <?php else: ?>
        <div class="row row-cols-2 row-cols-md-3 g-3">
          <?php while ($p = $rows->fetch_assoc()): ?>
            <div class="col"><?php include __DIR__ . '/includes/product_card.php'; ?></div>
          <?php endwhile; ?>
        </div>

        <?php if ($pages > 1): ?>
        <nav class="mt-4">
          <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $pages; $i++): ?>
              <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= url('products.php') . qs(['page' => $i]) ?>"><?= bn_num($i) ?></a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
