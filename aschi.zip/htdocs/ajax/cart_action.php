<?php
/** AJAX cart endpoint — add / update / remove. Returns JSON. */
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json; charset=utf-8');

function out($ok, $message = '') {
    echo json_encode([
        'ok'       => $ok,
        'message'  => $message,
        'count'    => cart_count(),
        'subtotal' => cart_subtotal(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(false, 'অনুমোদিত নয়।');

if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    out(false, 'সেশন মেয়াদ শেষ। পেজ রিফ্রেশ করুন।');
}

$action = $_POST['action'] ?? '';
$pid    = (int)($_POST['product_id'] ?? 0);
$qty    = (int)($_POST['qty'] ?? 1);

if ($action === 'add' || $action === 'update') {
    if (!ordering_open()) out(false, setting('order_off_message', 'এখন অর্ডার নেওয়া বন্ধ আছে।'));

    $stmt = $conn->prepare("SELECT id, name, stock FROM products WHERE id = ? AND status='active'");
    $stmt->bind_param('i', $pid);
    $stmt->execute();
    $p = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$p) out(false, 'পণ্যটি পাওয়া যায়নি।');
    if ((int)$p['stock'] <= 0) out(false, 'পণ্যটি স্টকে নেই।');

    if ($action === 'add') {
        $already = (int)($_SESSION['cart'][$pid] ?? 0);
        if ($already + $qty > (int)$p['stock']) out(false, 'স্টকে এর বেশি নেই।');
        cart_add($pid, $qty);
        out(true, $p['name'] . ' কার্টে যোগ হয়েছে।');
    }

    if ($qty > (int)$p['stock']) out(false, 'স্টকে এর বেশি নেই।');
    cart_set($pid, $qty);
    out(true, 'কার্ট আপডেট হয়েছে।');
}

if ($action === 'remove') { cart_remove($pid); out(true, 'পণ্যটি কার্ট থেকে সরানো হয়েছে।'); }
if ($action === 'clear')  { cart_clear();     out(true, 'কার্ট খালি করা হয়েছে।'); }

out(false, 'অজানা অনুরোধ।');
