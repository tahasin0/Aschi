<?php
require_once __DIR__ . '/includes/functions.php';

$code   = trim($_GET['code'] ?? '');
$order  = null;
$items  = [];
$rider  = null;
$notFound = false;

if ($code !== '') {
    $stmt = $conn->prepare(
        "SELECT o.*, r.name rider_name, r.phone rider_phone, r.photo rider_photo,
                r.social_link rider_social, r.current_lat, r.current_lng, r.location_updated_at
         FROM orders o LEFT JOIN riders r ON r.id = o.rider_id
         WHERE o.order_code = ?"
    );
    $stmt->bind_param('s', $code);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($order) {
        $s = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $s->bind_param('i', $order['id']);
        $s->execute();
        $items = $s->get_result()->fetch_all(MYSQLI_ASSOC);
        $s->close();

        $s = $conn->prepare("SELECT status, created_at FROM order_status_history WHERE order_id = ? ORDER BY id");
        $s->bind_param('i', $order['id']);
        $s->execute();
        $history = [];
        foreach ($s->get_result()->fetch_all(MYSQLI_ASSOC) as $h) $history[$h['status']] = $h['created_at'];
        $s->close();
    } else {
        $notFound = true;
    }
}

$__title = 'অর্ডার ট্র্যাকিং — Aschi';
require_once __DIR__ . '/includes/header.php';

$flow = ['pending','confirmed','rider_assigned','picked_up','on_the_way','delivered'];
$mapsKey = trim(setting('google_maps_key'));
?>

<main class="container py-4">
  <h1 class="h4 fw-bold mb-3">অর্ডার ট্র্যাক করুন</h1>

  <form class="card-soft p-3 mb-4" method="get">
    <label class="form-label" for="code">অর্ডার নম্বর</label>
    <div class="d-flex gap-2">
      <input class="form-control" id="code" name="code" value="<?= h($code) ?>" placeholder="যেমন ASC260913AB12X" required>
      <button class="btn btn-green px-4">খুঁজুন</button>
    </div>
    <?php if (!current_user()): ?>
      <p class="text-muted small mt-2 mb-0">লগইন করলে অ্যাকাউন্ট থেকেই সব অর্ডার দেখতে পারবেন।</p>
    <?php endif; ?>
  </form>

  <?php if ($notFound): ?>
    <div class="alert alert-warning">এই নম্বরে কোনো অর্ডার পাওয়া যায়নি। নম্বরটি মিলিয়ে দেখুন।</div>
  <?php endif; ?>

  <?php if ($order): ?>
  <div class="row g-4">
    <div class="col-lg-7">
      <div class="card-soft p-3 mb-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <div class="fw-bold fs-5"><?= h($order['order_code']) ?></div>
            <div class="text-muted small"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></div>
          </div>
          <span class="badge bg-<?= status_color($order['order_status']) ?>"><?= h(status_label($order['order_status'])) ?></span>
        </div>

        <?php if ($order['advance_paid_status'] !== 'not_required'): ?>
          <div class="notice-bar mb-3">
            অগ্রিম পেমেন্ট (TRX <?= h($order['trx_id']) ?>): <strong><?= h(payment_status_label($order['advance_paid_status'])) ?></strong>
          </div>
        <?php endif; ?>

        <h2 class="h6 fw-bold">অর্ডার স্ট্যাটাস</h2>
        <?php if ($order['order_status'] === 'cancelled'): ?>
          <div class="alert alert-danger mb-0">অর্ডারটি বাতিল করা হয়েছে।</div>
        <?php else: ?>
          <ul class="timeline mt-3">
            <?php
              $currentIndex = array_search($order['order_status'], $flow, true);
              foreach ($flow as $i => $st):
                $done = $currentIndex !== false && $i <= $currentIndex;
            ?>
              <li class="<?= $done ? 'done' : '' ?>">
                <div class="t-title"><?= h(status_label($st)) ?></div>
                <?php if (!empty($history[$st])): ?>
                  <div class="t-time"><?= date('d M, h:i A', strtotime($history[$st])) ?></div>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>

      <div class="card-soft p-3">
        <h2 class="h6 fw-bold mb-3">পণ্যের তালিকা</h2>
        <?php foreach ($items as $it): ?>
          <div class="d-flex justify-content-between mb-2">
            <span><?= h($it['product_name']) ?> <span class="text-muted small">× <?= bn_num($it['quantity']) ?> <?= h($it['unit']) ?></span></span>
            <span><?= taka($it['quantity'] * $it['price']) ?></span>
          </div>
        <?php endforeach; ?>
        <hr>
        <div class="d-flex justify-content-between"><span class="text-muted">সাবটোটাল</span><span><?= taka($order['subtotal']) ?></span></div>
        <div class="d-flex justify-content-between"><span class="text-muted">ডেলিভারি চার্জ</span><span><?= taka($order['delivery_charge']) ?></span></div>
        <div class="d-flex justify-content-between fw-bold fs-5 mt-2"><span>সর্বমোট</span><span class="text-green"><?= taka($order['total']) ?></span></div>
      </div>
    </div>

    <div class="col-lg-5">
      <?php if ($order['rider_id']): ?>
      <div class="card-soft p-3 mb-3">
        <h2 class="h6 fw-bold mb-3">আপনার রাইডার</h2>
        <div class="d-flex align-items-center gap-3">
          <?php $rp = $order['rider_photo']; ?>
          <img src="<?= $rp ? url('assets/images/riders/' . h($rp)) : url('assets/images/logo.png') ?>"
               alt="" width="58" height="58" class="rounded-circle" style="object-fit:cover">
          <div>
            <div class="fw-semibold"><?= h($order['rider_name']) ?></div>
            <a href="tel:<?= h($order['rider_phone']) ?>" class="small"><i class="bi bi-telephone"></i> <?= h($order['rider_phone']) ?></a>
            <?php if ($order['rider_social']): ?>
              <a href="<?= h($order['rider_social']) ?>" target="_blank" rel="noopener" class="small d-block">প্রোফাইল দেখুন</a>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="card-soft p-3">
        <h2 class="h6 fw-bold mb-2">লাইভ লোকেশন</h2>
        <?php if ($order['current_lat'] && $order['current_lng']): ?>
          <?php if ($mapsKey): ?>
            <div id="riderMap" style="height:300px;border-radius:12px"></div>
            <script>
              window.ASCHI_RIDER = { lat: <?= (float)$order['current_lat'] ?>, lng: <?= (float)$order['current_lng'] ?>,
                                     name: <?= json_encode($order['rider_name'], JSON_UNESCAPED_UNICODE) ?> };
              function initAschiMap() {
                var pos = { lat: window.ASCHI_RIDER.lat, lng: window.ASCHI_RIDER.lng };
                var map = new google.maps.Map(document.getElementById('riderMap'), { center: pos, zoom: 15 });
                new google.maps.Marker({ position: pos, map: map, title: window.ASCHI_RIDER.name });
              }
            </script>
            <script async src="https://maps.googleapis.com/maps/api/js?key=<?= h($mapsKey) ?>&callback=initAschiMap"></script>
          <?php else: ?>
            <iframe title="রাইডার লোকেশন" style="border:0;width:100%;height:300px;border-radius:12px" loading="lazy"
              src="https://maps.google.com/maps?q=<?= (float)$order['current_lat'] ?>,<?= (float)$order['current_lng'] ?>&z=15&output=embed"></iframe>
            <p class="text-muted small mt-2 mb-0">সেটিংসে Google Maps API key দিলে ইন্টার‍্যাক্টিভ ম্যাপ দেখাবে।</p>
          <?php endif; ?>
          <?php if ($order['location_updated_at']): ?>
            <p class="text-muted small mt-2 mb-0">সর্বশেষ আপডেট: <?= date('h:i A', strtotime($order['location_updated_at'])) ?></p>
          <?php endif; ?>
        <?php else: ?>
          <p class="text-muted mb-0">রাইডার রওনা দিলে এখানে লাইভ লোকেশন দেখা যাবে।</p>
        <?php endif; ?>
      </div>
      <?php else: ?>
      <div class="card-soft p-4 text-center">
        <div style="font-size:40px">🛵</div>
        <p class="text-muted mb-0">রাইডার নিযুক্ত হলে তার নাম, ফোন নম্বর আর লাইভ লোকেশন এখানে দেখা যাবে।</p>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
