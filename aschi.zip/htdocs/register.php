<?php
require_once __DIR__ . '/includes/functions.php';
if (current_user()) redirect('account.php');

$errors = [];
$f = ['name' => '', 'phone' => '', 'email' => '', 'address' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($f as $k => $_) $f[$k] = trim($_POST[$k] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if ($f['name'] === '')                 $errors['name'] = 'নাম লিখুন।';
    if (!valid_bd_phone($f['phone']))      $errors['phone'] = 'ফোন নাম্বার সঠিক নয় (যেমন ০১৭XXXXXXXX)।';
    if ($f['email'] !== '' && !filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'ইমেইল ঠিকানা সঠিক নয়।';
    if (strlen($password) < 6)             $errors['password'] = 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।';
    if ($password !== $confirm)            $errors['confirm'] = 'দুইবার লেখা পাসওয়ার্ড মিলছে না।';

    if (!$errors) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
        $stmt->bind_param('s', $f['phone']);
        $stmt->execute();
        if ($stmt->get_result()->num_rows) $errors['phone'] = 'এই নাম্বারে অ্যাকাউন্ট আছে — লগইন করুন।';
        $stmt->close();
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $email = $f['email'] !== '' ? $f['email'] : null;
        $stmt = $conn->prepare("INSERT INTO users (name, phone, email, password, address) VALUES (?,?,?,?,?)");
        $stmt->bind_param('sssss', $f['name'], $f['phone'], $email, $hash, $f['address']);
        $stmt->execute();
        $_SESSION['user_id'] = $conn->insert_id;
        $stmt->close();
        session_regenerate_id(true);
        flash('অ্যাকাউন্ট তৈরি হয়েছে। স্বাগতম!');
        redirect(cart_count() ? 'checkout.php' : 'account.php');
    }
}

$__title = 'রেজিস্ট্রেশন — Aschi';
require_once __DIR__ . '/includes/header.php';
?>
<main class="container py-5">
  <div class="card-soft p-4 mx-auto" style="max-width:480px">
    <h1 class="h5 fw-bold mb-1">অ্যাকাউন্ট খুলুন</h1>
    <p class="text-muted small">একবার তথ্য দিলে পরের অর্ডারে আর লিখতে হবে না।</p>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label" for="name">নাম</label>
        <input class="form-control <?= isset($errors['name'])?'is-invalid':'' ?>" id="name" name="name" value="<?= h($f['name']) ?>" required>
        <?php if(isset($errors['name'])): ?><div class="invalid-feedback"><?= h($errors['name']) ?></div><?php endif; ?>
      </div>
      <div class="mb-3">
        <label class="form-label" for="phone">মোবাইল নাম্বার</label>
        <input class="form-control <?= isset($errors['phone'])?'is-invalid':'' ?>" id="phone" name="phone" value="<?= h($f['phone']) ?>" placeholder="01XXXXXXXXX" inputmode="numeric" required>
        <?php if(isset($errors['phone'])): ?><div class="invalid-feedback"><?= h($errors['phone']) ?></div><?php endif; ?>
      </div>
      <div class="mb-3">
        <label class="form-label" for="email">ইমেইল (ঐচ্ছিক)</label>
        <input class="form-control <?= isset($errors['email'])?'is-invalid':'' ?>" id="email" name="email" type="email" value="<?= h($f['email']) ?>">
        <?php if(isset($errors['email'])): ?><div class="invalid-feedback"><?= h($errors['email']) ?></div><?php endif; ?>
      </div>
      <div class="mb-3">
        <label class="form-label" for="address">ঠিকানা</label>
        <textarea class="form-control" id="address" name="address" rows="2" placeholder="বাসা, রোড, এলাকা"><?= h($f['address']) ?></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label" for="password">পাসওয়ার্ড</label>
        <input class="form-control <?= isset($errors['password'])?'is-invalid':'' ?>" id="password" name="password" type="password" required>
        <?php if(isset($errors['password'])): ?><div class="invalid-feedback"><?= h($errors['password']) ?></div><?php endif; ?>
      </div>
      <div class="mb-3">
        <label class="form-label" for="confirm">পাসওয়ার্ড আবার লিখুন</label>
        <input class="form-control <?= isset($errors['confirm'])?'is-invalid':'' ?>" id="confirm" name="confirm" type="password" required>
        <?php if(isset($errors['confirm'])): ?><div class="invalid-feedback"><?= h($errors['confirm']) ?></div><?php endif; ?>
      </div>
      <button class="btn btn-green w-100">রেজিস্ট্রেশন সম্পন্ন করুন</button>
    </form>

    <p class="text-center text-muted small mt-3 mb-0">
      আগে থেকেই অ্যাকাউন্ট আছে? <a href="<?= url('login.php') ?>" class="fw-semibold">লগইন করুন</a>
    </p>
  </div>
</main>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
